---
# OffshoreInstallationsA

**UUID:** 01f891cc-49ec-4ba6-8b08-6b8923994441  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/01f891cc-49ec-4ba6-8b08-6b8923994441  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/01f891cc-49ec-4ba6-8b08-6b8923994441/documents/5d62dd1b-9f95-42fa-a272-05491f2df967  
**Scraped:** 2026-04-26T05:16:56+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Offshore Installations (Area) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/offshoreinstallationsa-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Polygon features to represent offshore structures either fixed or floating and this includes offshore platforms, offshore production areas and wellheads etc., illustrating the area covered by this geographic object.

These polygon features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S-57).

This dataset is not to be used for navigation.

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/offshoreinstallationsa-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_offshoreinstallationsa.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_offshoreinstallationsa.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/offshoreinstallationsa-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_offshoreinstallationsa.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

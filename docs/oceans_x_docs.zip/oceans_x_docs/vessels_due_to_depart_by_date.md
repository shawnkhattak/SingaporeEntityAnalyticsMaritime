---
# Vessels Due to Depart by Date

**UUID:** dac77729-be46-46f5-847d-13db294a2542  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/dac77729-be46-46f5-847d-13db294a2542  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/dac77729-be46-46f5-847d-13db294a2542/documents/149e3342-1e38-4b23-ba19-e86f9da73c95  
**Scraped:** 2026-04-26T05:23:05+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessels Due to Depart by Date API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/duetodepart/date/{date}`  
**Update Frequency:** 1 hour  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessels that are due to depart information for the given date in yyyy-MM-dd format. The data is updated every hour.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /date/{date}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | Yes | Should be in date (yyyy-MM-dd) format | `2021-12-16` |

---

## 🧾 **Attributes Description**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | KOTA GABUNG |
| callSign | string | Vessel call sign | VRQR3 |
| imoNumber | string | IMO number of the vessel | 9616852 |
| flag | string | Country flag of the vessel | HK |
| dueToDepart | string | Vessel due to depart time | 2021-12-16 15:00:00 |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "vesselParticulars": {
            "vesselName": "KOTA GABUNG",
            "callSign": "VRQR3",
            "imoNumber": "9616852",
            "flag": "HK"
        },
        "dueToDepart": "2021-12-16 15:00:00"
    },
    {
        "vesselParticulars": {
            "vesselName": "OCEANA BLUE",
            "callSign": "",
            "imoNumber": "0",
            "flag": "ID"
        },
        "dueToDepart": "2021-12-16 16:30:00"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "timestamp": "2025-07-24T10:00:00.000Z",
        "message": "Input Constraint Violation: One or more input parameters are not valid.",
        "code": "BAD_REQUEST"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/duetodepart/date/2021-12-16' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the date if needed.
- Ensure the `apikey` has sufficient access rights to call this endpoint.

---

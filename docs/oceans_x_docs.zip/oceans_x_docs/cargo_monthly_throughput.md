---
# Cargo Monthly Throughput

**UUID:** 71e9eacb-b866-41fb-83c0-d8a60b03a23b  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/71e9eacb-b866-41fb-83c0-d8a60b03a23b  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/71e9eacb-b866-41fb-83c0-d8a60b03a23b/documents/252cdcb6-ce90-4fd5-bfa5-bf3d7d37d2fc  
**Scraped:** 2026-04-26T04:11:57+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Cargo Monthly Throughput (ZIP) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/staticdataset/cargoMonthlyThroughput`  
**Update Frequency:** Monthly

---

## 🔍 **Overview**

Provides the corresponding cargo monthly throughput data in zip format.

---

## 📥 **Request**

### `GET /v1/staticdataset/cargoMonthlyThroughput`

No query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="cargo-throughput-monthly.zip"` |

#### Response Body:

Binary content of the ZIP file (`cargo-throughput-monthly.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/staticdataset/cargoMonthlyThroughput' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'cargo-throughput-monthly.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

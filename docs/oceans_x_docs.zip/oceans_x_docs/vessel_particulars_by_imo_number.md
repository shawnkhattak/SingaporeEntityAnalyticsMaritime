---
# Vessel Particulars by IMO Number

**UUID:** 7e71547c-19d1-4435-918a-d3ec5d2ecbb8  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/7e71547c-19d1-4435-918a-d3ec5d2ecbb8  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/7e71547c-19d1-4435-918a-d3ec5d2ecbb8/documents/b6ce0bf1-e3f8-429d-9b9d-e5820138ec1e  
**Scraped:** 2026-04-26T05:21:48+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Particulars by IMO Number API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/particulars/imonumber/{imonumber}`  
**Update Frequency:** 6 Hours  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessel particulars information for the given vessel IMO number. The data is updated every 6 hours.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /imonumber/{imonumber}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| imonumber | string | Yes | IMO number of vessel (1-10 chars, regex: `/^[a-zA-Z0-9]+$/`) | `7356305` |

---

## 🧾 **Response Details**

### Singapore-flagged vessel (`flag = "SG"`)

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | I MOLA |
| callSign | string | Vessel call sign | 9V5704 |
| imoNumber | string | IMO number of the vessel | 9204025 |
| flag | string | Country flag of the vessel | SG |
| vesselLength | number | Length of the vessel | 31 |
| vesselBreadth | number | Breadth of the vessel | 7 |
| vesselDepth | number | Depth of the vessel | 2 |
| vesselType | string | Type of vessel | FB |
| grossTonnage | number | Gross tonnage of the vessel | 240 |
| netTonnage | number | Net tonnage of the vessel | 72 |
| deadweight | number | Dead weight of the vessel | 0 |
| mmsiNumber | string | MMSI number of the vessel | 564759000 |
| yearBuilt | string | Year built | 1995 |
| ismManager | string | ISM Manager | SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD |
| shipManager | string | Ship Manager | SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD |
| registeredOwnership | string | Registered Ownership | SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD |
| classificationSociety | string | Classification Society | MPA |

### Non-Singapore-flagged vessel (`flag != "SG"`)

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | IONA |
| callSign | string | Vessel call sign | VRWN5 |
| imoNumber | string | IMO number of the vessel | 7356305 |
| flag | string | Country flag of the vessel | HK |
| vesselLength | number | Length of the vessel | 183 |
| vesselBreadth | number | Breadth of the vessel | 0 |
| vesselDepth | number | Depth of the vessel | 0 |
| vesselType | string | Type of vessel | TA |
| grossTonnage | number | Gross tonnage of the vessel | 22988 |
| netTonnage | number | Net tonnage of the vessel | 11840 |
| deadweight | number | Dead weight of the vessel | 39860 |
| mmsiNumber | string | MMSI number of the vessel | 477123900 |
| yearBuilt | string | Year built | 1974 |

---

## 📤 **Response**

### ✅ 200 OK

#### Case 1: Singapore-flagged vessel (`flag = "SG"`)

```
[
    {
        "vesselName": "I MOLA",
        "callSign": "9V5704",
        "imoNumber": "9204025",
        "flag": "SG",
        "vesselLength": 31,
        "vesselBreadth": 7,
        "vesselDepth": 2,
        "vesselType": "FB",
        "grossTonnage": 240,
        "netTonnage": 72,
        "deadweight": 0,
        "mmsiNumber": "564759000",
        "yearBuilt": "1995",
        "ismManager": "SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD",
        "shipManager": "SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD",
        "registeredOwnership": "SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD",
        "classificationSociety": "MPA"
    }
]
```

#### Case 2: Non-Singapore-flagged vessel (`flag != "SG"`)

```
[
    {
        "vesselName": "IONA",
        "callSign": "VRWN5",
        "imoNumber": "7356305",
        "flag": "HK",
        "vesselLength": 183,
        "vesselBreadth": 0,
        "vesselDepth": 0,
        "vesselType": "TA",
        "grossTonnage": 22988,
        "netTonnage": 11840,
        "deadweight": 39860,
        "mmsiNumber": "477123900",
        "yearBuilt": "1974"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/particulars/imonumber/7356305' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the imo number if it includes special characters.
- Ensure the `apikey` has sufficient access rights to call this endpoint.

---

---
# Master Plan 2019 SDCP Nature Boundary layer

**UUID:** 1ec73a09-5504-4b47-931c-aae0be808f47  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/1ec73a09-5504-4b47-931c-aae0be808f47  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/1ec73a09-5504-4b47-931c-aae0be808f47/documents/031e6726-d73d-4884-9d8c-0e660cd905e2  
**Scraped:** 2026-04-26T05:16:10+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Master Plan Nature Boundary Layer API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/ura/master-plan-nature-boundary-layer`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Provides access to the URA Master Plan Nature Boundary Layer dataset. This API returns a reference URL to the data.gov.sg portal where the dataset collection can be accessed and downloaded.

---

## 📥 **Request**

### `GET /v1/gssdataset/ura/master-plan-nature-boundary-layer`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response contains a JSON object with a `location` field pointing to the data.gov.sg collection page.

#### Response Body:

```
{
    "location": "https://data.gov.sg/collections/1733/view"
}
```

#### Response Fields:

| Field | Type | Description |
| --- | --- | --- |
| location | string | URL to the data.gov.sg collection page where the Master Plan Nature Boundary Layer dataset can be accessed and downloaded |

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/ura/master-plan-nature-boundary-layer' \
  -H 'ApiKey: YOUR_API_KEY'
```

---

## 📎 Notes

- The API returns a reference URL to data.gov.sg, not the actual dataset file.
- Users should navigate to the provided URL to access and download the dataset from data.gov.sg.
- No request body or query parameters required.

---

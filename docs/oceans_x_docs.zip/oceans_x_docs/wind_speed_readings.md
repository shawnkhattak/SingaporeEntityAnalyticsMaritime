---
# Wind Speed Readings

**UUID:** 52d70022-3cd5-46a0-8d40-9d8e5b33a92e  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/52d70022-3cd5-46a0-8d40-9d8e5b33a92e  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/52d70022-3cd5-46a0-8d40-9d8e5b33a92e/documents/0ab68c1b-05f7-4a36-b017-e0293fc07d8e  
**Scraped:** 2026-04-26T05:23:31+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Weather - Real-Time Wind Speed API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{DOMAIN}/api/weather/real-time/1.0.0/wind-speed-readings`  
**Update Frequency:** 5 minutes  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Minute-by-minute wind speed readings at weather-station level, updated every five minutes. Data is retrieved from NEA’s open data API and refreshed frequently.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /real-time/wind-speed`

### 🔧 Path Parameters

*None*

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | No | SGT date for which to retrieve data (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS) | `2025-07-24T11:00:00` |
| paginationToken | string | No | Pagination token for retrieving subsequent data pages (only exists when there is a next page available for requests with date filters) | `abc123` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| code | integer | Response status code (always 0 for success) | 0 |
| data | object | Wind speed data object | See below (Data Object) |
| errorMsg | string | Error message (empty string for success) | "" |

**Data Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| stations | array | List of weather stations | See below (Station Object) |
| readings | array | List of wind speed readings | See below (Reading Object) |
| readingType | string | Information about the reading | Wind Speed AVG(S)10M M1M |
| readingUnit | string | Measurement unit for reading | knots |
| paginationToken | string | Token to retrieve next page if exists | b2Zmc2V0PTEwMA== |

**Station Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| id | string | Station's ID | S108 |
| deviceId | string | Reading Device's ID (usually same as Station's ID) | S108 |
| name | string | Station's name | Marina Gardens Drive |
| location | object | Latitude/longitude | See below (Location Object) |

**Location Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| latitude | number | Latitude coordinate of the region label | 1.2799 |
| longitude | number | Longitude coordinate of the region label | 103.8703 |

**Reading Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| timestamp | string | Timestamp of reading | 2025-07-24T11:52:00+08:00 |
| data | array | Array of station readings | See below (Station Reading Object) |

**Station Reading Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| stationId | string | Station ID | S108 |
| value | number | Wind speed value (knots) | 1.8 |

---

## 📤 **Response**

### ✅ HTTP Status Code: 200

```
{
  "code": 0,
  "data": {
    "stations": [
      {
        "id": "S108",
        "deviceId": "S108",
        "name": "Marina Gardens Drive",
        "location": {
          "latitude": 1.2799,
          "longitude": 103.8703
        }
      }
    ],
    "readings": [
      {
        "timestamp": "2025-07-24T11:48:00+08:00",
        "data": [
          {
            "stationId": "S108",
            "value": 2.1
          },
          {
            "stationId": "S109",
            "value": 1.8
          },
          {
            "stationId": "S106",
            "value": 3.2
          }
        ]
      }
    ],
    "readingType": "Wind Speed 10M M1M",
    "readingUnit": "m/s",
    "paginationToken": "b2Zmc2V0PTEwMA=="
  },
  "errorMsg": ""
}
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
  "error": {
    "code": "400",
    "message": "Invalid or missing request parameters",
    "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
  }
}
```

### ❌ HTTP Status Code: 4xx/5xx from NEA:

```
{
  "code": 4,
  "name": "ERROR_PARAMS",
  "data": null,
  "errorMsg": "Invalid date format. Date format must be YYYY-MM-DD (2024-06-01) or YYYY-MM-DDTHH:mm:ss (2024-06-01T08:30:00)."
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/weather/real-time/1.0.0/wind-speed-readings?date=2025-07-24T11:00:00' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Has per-minute readings from NEA
- Filter for specific date or date-time by providing date in query parameter:
  - Use `YYYY-MM-DD` format to retrieve all of the readings for that day
  - Use `YYYY-MM-DDTHH:mm:ss` to retrieve the latest readings at that moment in time
  - Example: `?date=2024-07-16` or `?date=2024-07-16T23:59:00`
- If date is not provided in query parameter, API will return the latest reading
- Unit of measure for readings is Knots

---

---
# Coastal and Marine Habitat Map of Singapore 2018

**UUID:** 110b63f5-d8f3-4d19-b15a-19ed5cf8ed4d  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/110b63f5-d8f3-4d19-b15a-19ed5cf8ed4d  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/110b63f5-d8f3-4d19-b15a-19ed5cf8ed4d/documents  
**Scraped:** 2026-04-26T05:14:51+00:00

---

​

​

## API Documentation

---
# DepthsA

**UUID:** 6fab286e-cc59-481c-b217-ffa3baee089e  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/6fab286e-cc59-481c-b217-ffa3baee089e  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/6fab286e-cc59-481c-b217-ffa3baee089e/documents/5f9e8fb2-bf9e-4c44-b26a-1c374a0a6938  
**Scraped:** 2026-04-26T05:15:55+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Depths (Area) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/depthsa-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Polygon features to represent depth area of a water, illustrating the area covered by this geographic object.

These polygon features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S-57).

This dataset is not to be used for navigation.

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/depthsa-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_depthsa.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_depthsa.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/depthsa-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_depthsa.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

---
# Vessel Departure Declaration by IMO Number

**UUID:** 743c4889-1d03-4da7-a7d4-29b2de675839  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/743c4889-1d03-4da7-a7d4-29b2de675839  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/743c4889-1d03-4da7-a7d4-29b2de675839/documents/571b1fb5-17ab-4097-acc3-a7545cae55ad  
**Scraped:** 2026-04-26T05:20:34+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 Vessel Departure Declaration by IMO Number API

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/departuredeclaration/imonumber/{imonumber}`  
**Update Frequency:** Hourly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 Overview

Provides the vessel departure declaration information for the given IMO number. Data is updated hourly.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /imonumber/{imonumber}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Example |
| --- | --- | --- | --- | --- |
| imonumber | string | Yes | IMO number of vessel | `1103512` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars information | {...} |
| agent | string | Agent of the vessel | MAJESTIC FAST FERRY PTE LTD |
| nextPort | string | Next port | BATAM CENTRE (BATAM) |
| reportedArrivalTime | string | Reported arrival time | 2025-07-26 08:15:00 |
| reportedDepartureTime | string | Reported departure time | 2025-07-26 09:49:24 |
| crew | string | Crew count | 10 |
| pax | string | Passenger count | 249 |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | STELLAR OF MAJESTIC |
| callSign | string | CallSign of the vessel | 9VCP7 |
| imoNumber | string | IMO number of the vessel | 1103512 |
| flag | string | Country flag of the vessel | SG |

---

## 📤 **Response**

### ✅ 200 OK

```
[
  {
    "vesselParticulars": {
      "vesselName": "STELLAR OF MAJESTIC",
      "callSign": "9VCP7",
      "imoNumber": "1103512",
      "flag": "SG"
    },
    "agent": "MAJESTIC FAST FERRY PTE LTD",
    "nextPort": "BATAM CENTRE (BATAM)",
    "reportedArrivalTime": "2025-07-26 08:15:00",
    "reportedDepartureTime": "2025-07-26 09:49:24",
    "crew": "10",
    "pax": "249"
  }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/departuredeclaration/imonumber/1103512' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Returns all departure declarations for the given IMO number.
- Make sure to **URL-encode** the IMO number if it includes spaces or special characters.

---

---
# Last Vessel Arrival Declaration by Vessel Name

**UUID:** 35149af0-867e-45b0-a4e6-c330d45d0c57  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/35149af0-867e-45b0-a4e6-c330d45d0c57  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/35149af0-867e-45b0-a4e6-c330d45d0c57/documents/d3ec8ddb-28a1-4163-ba20-819c4ca61ee8  
**Scraped:** 2026-04-26T04:12:36+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Last Vessel Arrival Declaration by Vessel Name API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/arrivaldeclaration/last/vesselname/{vesselname}`  
**Update Frequency:** Hourly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding latest vessel arrival declaration information for the given vessel name. The data is updated every hour

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /last/vesselname/{vesselname}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| vesselname | string | Yes | Name of the vessel | `RADJA SAMUDERA ABADI` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars information | {...} |
| location | string | Location of the vessel | J15 |
| grid | string | Grid of the vessel | "" |
| purpose | string | The purpose field is a comma-separated value (CSV) field, where each value is a Yes (Y) or No (N) indicator in the following sequence: #1 – Loading/Unloading Cargo, #2 – Loading/Unloading Passengers, #3 – Taking Bunker, #4 – Taking Ship Supplies, #5 – Changing Crew, #6 – Shipyard Repair, #7 – Offshore Support, #8 – Not Used, #9 – Other Afloat Activities. | Y,N,N,N,N,N,N,N,N, |
| agent | string | Agent of the vessel | INFINITI SHIPPING PTE LTD |
| reportedArrivalTime | string | The reported arrival time | 2024-01-23 15:25:00 |
| crew | string | Number of crew members | 13 |
| pax | string | Number of passengers | 0 |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | RADJA SAMUDERA ABADI |
| callSign | string | CallSign of the vessel | PKJQ |
| imoNumber | string | IMO number of the vessel | 9762156 |
| flag | string | Country flag of the vessel | ID |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "vesselParticulars": {
            "vesselName": "RADJA SAMUDERA ABADI",
            "callSign": "PKJQ",
            "imoNumber": "9762156",
            "flag": "ID"
        },
        "location": "J15",
        "grid": "",
        "purpose": "Y,N,N,N,N,N,N,N,N,",
        "agent": "INFINITI SHIPPING PTE LTD",
        "reportedArrivalTime": "2024-01-23 15:25:00",
        "crew": "13",
        "pax": "0"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/arrivaldeclaration/last/vesselname/RADJA%20SAMUDERA%20ABADI' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the vessel name if it includes spaces.
- The API supports **hourly refreshed** data from the Maritime Data Hub.

---

---
# Country Codes Data In Zipped CSV Format

**UUID:** 06467e5f-f3f1-4fca-868f-da5eafdffb0e  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/06467e5f-f3f1-4fca-868f-da5eafdffb0e  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/06467e5f-f3f1-4fca-868f-da5eafdffb0e/documents/7e1d63d5-bbed-4475-99d9-0e77353dd7fb  
**Scraped:** 2026-04-26T04:12:23+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Country Codes Data (Zipped CSV) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/mdhvessel/reference/countries/filetype/csvzip`  
**Update Frequency:** Daily  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding country codes lookup data directly as a zipped CSV file.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /v1/mdhvessel/reference/countries/filetype/csvzip`

No query parameters required.

---

## 🧾 **Response Details**

| Header | Type | Description | Example |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | application/zip |
| Content-Disposition | string | File attachment information | attachment; filename="COUNTRIES\_REF\_CSV.zip" |

## 📤 **Response**

### ✅ 200 OK

The response returns the country codes data directly as a zipped CSV file for download.

**Response Type:** Binary file (application/zip)  
**File Name:** COUNTRIES\_REF\_CSV.zip  
**Content:** CSV file

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/mdhvessel/reference/countries/filetype/csvzip' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- The response returns the zipped CSV file directly in the response body for immediate download.
- No request body or query parameters required.
- The ZIP file contains CSV data

---

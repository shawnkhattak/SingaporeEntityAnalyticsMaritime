---
# Container Monthly Throughput

**UUID:** 005a55e8-39e1-4a49-986f-8787db025056  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/005a55e8-39e1-4a49-986f-8787db025056  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/005a55e8-39e1-4a49-986f-8787db025056/documents/7992d910-6e34-4255-8e08-6120ed0a9cfc  
**Scraped:** 2026-04-26T04:12:10+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Container Monthly Throughput (ZIP) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/staticdataset/containerMonthlyThroughput`  
**Update Frequency:** Monthly

---

## 🔍 **Overview**

Provides the corresponding container monthly throughput data in zip format.

---

## 📥 **Request**

### `GET /v1/staticdataset/containerMonthlyThroughput`

No query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="container-throughput-monthly-total.zip"` |

#### Response Body:

Binary content of the ZIP file (`container-throughput-monthly-total.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/staticdataset/containerMonthlyThroughput' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'container-throughput-monthly-total.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

---
# 4-Days Weather Forecast

**UUID:** 2084ab03-247d-4ca1-b806-742cbdb47650  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/2084ab03-247d-4ca1-b806-742cbdb47650  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/2084ab03-247d-4ca1-b806-742cbdb47650/documents/14f1c08c-0496-41f5-a85e-b13f9b92c960  
**Scraped:** 2026-04-26T04:11:13+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Weather - 4-Day Forecast API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{DOMAIN}/api/weather/forecast/1.0.0/4day-forecasts`  
**Update Frequency:** 12 hours  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Weather forecast for the next 4 days. Data is retrieved from NEA’s open data API.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /forecast/4day`

### 🔧 Path Parameters

*None*

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | No | SGT date for which to retrieve data (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS) | `2025-07-24` or `2025-07-24T11:30:00` |
| paginationToken | string | No | Pagination token for retrieving subsequent data pages (only exists when there is a next page available for requests with date filters) | `b2Zmc2V0PTEwMA==` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| code | integer | Response status code (always 0 for success) | 0 |
| data | object | Weather forecast data object | See below (Data Object) |
| errorMsg | string | Error message (empty string for success) | "" |

**Data Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| records | array | List of forecast records | See below (Record Object) |

**Record Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| date | string | Date of forecast | 2025-07-24 |
| updatedTimestamp | string | Time of last update from NEA | 2025-07-24T11:40:59+08:00 |
| timestamp | string | Time forecast was issued by NEA | 2025-07-24T11:30:00+08:00 |
| forecasts | array | Forecast summary for the day | See below (Forecast Object) |

**Forecast Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| temperature | object | Unit of measure - Degrees Celsius | See below (Temperature Table) |
| relativeHumidity | object | Unit of measure - Percentage | See below (Relative Humidity Table) |
| forecast | object | Forecast summary, code, and text | See below (Forecast Table) |
| day | string | Day of the week | Friday |
| timestamp | string | Date/time for the forecasted day | 2025-07-25T00:00:00+08:00 |
| wind | object | Wind speed and direction | See below (Wind Object) |

**Temperature Table:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| low | number | Lowest temperature (°C) | 25 |
| high | number | Highest temperature (°C) | 33 |
| unit | string | Unit of measure | Degrees Celsius |

**Relative Humidity Table:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| low | number | Lowest relative humidity (%) | 50 |
| high | number | Highest relative humidity (%) | 95 |
| unit | string | Unit of measure | Percentage |

**Forecast Table:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| summary | string | Forecast summary | Afternoon thundery showers |
| code | string | Forecast code | TL |
| text | string | Forecast text | Thundery Showers |

**Wind Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| speed | object | Unit of measure - Kilometres per hour | See below (Wind Speed Object) |
| direction | string | Wind direction | SSE |

**Wind Speed Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| low | number | Lowest wind speed | 10 |
| high | number | Highest wind speed | 15 |

---

## 📤 **Response**

### ✅ HTTP Status Code: 200

```
{
  "code": 0,
  "data": {
    "records": [
      {
        "date": "2025-07-24",
        "updatedTimestamp": "2025-07-24T11:40:59+08:00",
        "timestamp": "2025-07-24T11:30:00+08:00",
        "forecasts": [
          {
            "temperature": {
              "low": 25,
              "high": 33,
              "unit": "Degrees Celsius"
            },
            "relativeHumidity": {
              "low": 50,
              "high": 95,
              "unit": "Percentage"
            },
            "forecast": {
              "summary": "Afternoon thundery showers",
              "code": "TL",
              "text": "Thundery Showers"
            },
            "day": "Friday",
            "timestamp": "2025-07-25T00:00:00+08:00",
            "wind": {
              "speed": {
                "low": 10,
                "high": 15
              },
              "direction": "SSE"
            }
          },
          {
            "temperature": {
              "low": 25,
              "high": 34,
              "unit": "Degrees Celsius"
            },
            "relativeHumidity": {
              "low": 60,
              "high": 95,
              "unit": "Percentage"
            },
            "forecast": {
              "summary": "Afternoon thundery showers",
              "code": "TL",
              "text": "Thundery Showers"
            },
            "day": "Saturday",
            "timestamp": "2025-07-26T00:00:00+08:00",
            "wind": {
              "speed": {
                "low": 10,
                "high": 15
              },
              "direction": "S"
            }
          }
        ]
      }
    ]
  },
  "errorMsg": ""
}
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
  "error": {
    "code": "400",
    "message": "Invalid or missing request parameters",
    "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
  }
}
```

### ❌ HTTP Status Code: 4xx/5xx from NEA:

```
{
  "code": 4,
  "name": "ERROR_PARAMS",
  "data": null,
  "errorMsg": "Invalid date format. Date format must be YYYY-MM-DD (2024-06-01) or YYYY-MM-DDTHH:mm:ss (2024-06-01T08:30:00)."
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/weather/forecast/1.0.0/4day-forecasts?date=2025-07-24' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Updated twice a day from NEA
- The forecast is for the next 4 days.
- Filter for specific date or date-time by providing date in query parameter:
  - Use `YYYY-MM-DD` format to retrieve all of the readings for that day
  - Use `YYYY-MM-DDTHH:mm:ss` to retrieve the latest readings at that moment in time
  - Example: `?date=2024-07-16` or `?date=2024-07-16T23:59:00`
- If date is not provided in query parameter, API will return the latest reading

---

---
# SRS Certificate by Certificate Number

**UUID:** a50e5176-da0f-4d9e-aeaf-46e08b78d257  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/a50e5176-da0f-4d9e-aeaf-46e08b78d257  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/a50e5176-da0f-4d9e-aeaf-46e08b78d257/documents/58946093-53cd-4e5c-bde5-8438a00328c8  
**Scraped:** 2026-04-26T05:18:41+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **SRS Certificate of Registry by Certificate Number API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/srscor/certificatenumber/{certificatenumber}`  
**Update Frequency:** Hourly  
**Authentication:** `API Key` (via `apikey` header)

---

the given Certificate Number. The data is updated every hour.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /certificatenumber/{certificatenumber}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| certificatenumber | string | Yes | SRS Certificate Number | COR-0001-18 |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| shipName | string | Name of the ship | AFRIK HAWK |
| imoNumber | string | IMO number of the vessel | 9214355 |
| registrationStatus | string | Registration status | I |
| registrationDate | string | Registration date | 2016-03-03 00:00:00 |
| validityDate | string | Validity date | 2017-03-03 00:00:00 |
| dateOfClosure | string | Date of closure | 2019-07-15 00:00:00 |
| certificateNumber | string | Certificate Number | COR-0001-18 |
| issueDate | string | Issue date | 2018-02-28 |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "shipName": "AFRIK HAWK",
        "imoNumber": "9214355",
        "registrationStatus": "I",
        "registrationDate": "2016-03-03 00:00:00",
        "validityDate": "2017-03-03 00:00:00",
        "dateOfClosure": "2019-07-15 00:00:00",
        "certificateNumber": "COR-0001-18",
        "issueDate": "2018-02-28"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/srscor/certificatenumber/COR-0001-18' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the certificate number if it includes special characters.

---

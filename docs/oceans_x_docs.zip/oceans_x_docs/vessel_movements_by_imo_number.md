---
# Vessel Movements by IMO Number

**UUID:** cc722eba-f98f-4430-a482-066c4dff35d8  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/cc722eba-f98f-4430-a482-066c4dff35d8  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/cc722eba-f98f-4430-a482-066c4dff35d8/documents/146a1a14-72af-45d6-9458-0c2d6373a70d  
**Scraped:** 2026-04-26T05:21:29+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Movements by IMO Number API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/movements/imonumber/{imonumber}`  
**Update Frequency:** 5 minutes  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessel movements information for the given vessel IMO number. The data is updated every 5 minutes.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /imonumber/{imonumber}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| imonumber | string | Yes | IMO number of vessel | `9378785` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars object | {...} |
| movementStartDateTime | string | Movement start datetime (YYYY-MM-DD HH:MM:SS) | 2023-09-21 22:20:00 |
| movementEndDateTime | string | Movement end datetime (YYYY-MM-DD HH:MM:SS) | 2023-09-21 22:20:00 |
| movementStatus | string | Movement status code | C |
| movementType | string | Movement type code | A |
| locationFrom | string | Location from | SEAE |
| locationTo | string | Location to | PGBG |
| movementDraft | string | Movement draft | 096 |
| movementHeight | string | Movement height | 28 |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | CNC BULL |
| callSign | string | Vessel call sign | D7AZ |
| imoNumber | string | IMO number of the vessel | 9378785 |
| flag | string | Country flag of the vessel | KR |

---

## 📤 **Response**

### ✅ 200 OK

```
[
  {
    "vesselParticulars": {
      "vesselName": "CNC BULL",
      "callSign": "D7AZ",
      "imoNumber": "9378785",
      "flag": "KR"
    },
    "movementStartDateTime": "2023-09-21 22:20:00",
    "movementEndDateTime": "2023-09-21 22:20:00",
    "movementStatus": "C",
    "movementType": "A",
    "locationFrom": "SEAE",
    "locationTo": "PGBG",
    "movementDraft": "096",
    "movementHeight": "28"
  },
  {
    "vesselParticulars": {
      "vesselName": "CNC BULL",
      "callSign": "D7AZ",
      "imoNumber": "9378785",
      "flag": "KR"
    },
    "movementStartDateTime": "2023-09-21 22:20:00",
    "movementEndDateTime": "2023-09-21 23:55:00",
    "movementStatus": "C",
    "movementType": "I",
    "locationFrom": "PGBG",
    "locationTo": "ASSPU",
    "movementDraft": "096",
    "movementHeight": "28"
  }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/movements/imonumber/9378785' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the IMO number if it includes special characters.
- The API returns movement data for the specified IMO number.
- Ensure the `apikey` has sufficient access rights to call this endpoint.

---

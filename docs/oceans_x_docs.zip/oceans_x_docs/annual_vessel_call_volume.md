---
# Annual Vessel Call Volume

**UUID:** 49404a9e-9a08-4df7-8738-dd6042e31aed  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/49404a9e-9a08-4df7-8738-dd6042e31aed  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/49404a9e-9a08-4df7-8738-dd6042e31aed/documents/467bbf68-3cf1-4442-b5d5-bbf4808313d2  
**Scraped:** 2026-04-26T04:11:31+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Distribution - Vessel Call Volume Annual API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{DOMAIN}/api/vessel-call/1.0.0/annual-volume`  
**Update Frequency:** Monthly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides annual vessel call volume statistics, including breakdown by purpose type. Data is sourced from Data.gov.sg and updated monthly.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /annual-volume`

### 🔧 Path Parameters

*None*

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| startYear | string | Yes | Start year in YYYY format | `2002` |
| endYear | string | Yes | End year in YYYY format | `2003` |
| purposeType | string | No | Purpose type filter (bunkers, cargo, repairs, supplies, others) | `cargo` |
| page | integer | No | Page number (1-indexed), minimum: 1 | `1` |
| size | integer | No | Number of records per page, minimum: 1, maximum: 100 | `20` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| items | array | Array of vessel call volume records | See below (Items Array Item) |
| page | object | Pagination metadata | See below (Page Object) |
| \_links | object | Hypermedia links for navigation | See below (Links Object) |

**Items Array Item:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| year | integer | Year in YYYY format | 2023 |
| purposeType | string | Purpose type of vessel call | "cargo" |
| numberOfVesselCalls | integer | Number of vessel calls for the purpose type | 1890 |
| grossTonnage | number | Total gross tonnage for the purpose type | 38200000 |

**Page Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| number | integer | Current page number (1-indexed) | 1 |
| size | integer | Number of items per page | 3 |
| totalElements | integer | Total number of elements across all pages | 42 |
| totalPages | integer | Total number of pages | 14 |

**Links Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| self | object | Link to current page | `{"href": "/api/vessel-call/1.0.0/annual-volume?startYear=2023&endYear=2025&page=2&size=3"}` |
| prev | object | Link to previous page (if exists) | `{"href": "/api/vessel-call/1.0.0/annual-volume?startYear=2023&endYear=2025&page=1&size=3"}` |
| next | object | Link to next page (if exists) | `{"href": "/api/vessel-call/1.0.0/annual-volume?startYear=2023&endYear=2025&page=3&size=3"}` |

---

## 📤 **Response**

### ✅ HTTP Status Code: 200

```
{
  "items": [
    {
      "year": 2023,
      "purposeType": "cargo",
      "numberOfVesselCalls": 1890,
      "grossTonnage": 38200000
    },
    {
      "year": 2024,
      "purposeType": "cargo",
      "numberOfVesselCalls": 1950,
      "grossTonnage": 40500000
    },
    {
      "year": 2025,
      "purposeType": "cargo",
      "numberOfVesselCalls": 1080,
      "grossTonnage": 22100000
    }
  ],
  "page": {
    "number": 1,
    "size": 3,
    "totalElements": 42,
    "totalPages": 14
  },
  "_links": {
    "self": {
      "href": "/api/vessel-call/1.0.0/annual-volume?startYear=2023&endYear=2025&page=2&size=3"
    },
    "next": {
      "href": "/api/vessel-call/1.0.0/annual-volume?startYear=2023&endYear=2025&page=3&size=3"
    },
    "prev": {
      "href": "/api/vessel-call/1.0.0/annual-volume?startYear=2023&endYear=2025&page=1&size=3"
    }
  }
}
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
  "error": {
    "code": "400",
    "message": "Invalid or missing request parameters",
    "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
  }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/vessel-call/1.0.0/annual-volume?startYear=2002&endYear=2003&page=1&size=20' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Data is updated monthly.
- Results are paginated. Use `page` and `size` parameters to control pagination.
- If `purposeType` is not provided, all purpose types will be included in the response.

---

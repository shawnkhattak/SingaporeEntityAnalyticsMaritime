---
# List of Vessel Particulars by name

**UUID:** 413d5064-b166-4a2a-b8e5-4c3383ba58e1  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/413d5064-b166-4a2a-b8e5-4c3383ba58e1  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/413d5064-b166-4a2a-b8e5-4c3383ba58e1/documents/b168ba3b-24b4-473b-bec3-73adaf47215d  
**Scraped:** 2026-04-26T04:12:42+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Particulars by Name API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/particulars/name/{charset}`  
**Update Frequency:** As per source system  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding List of vessel particulars information (imo number and vessel name) for the given charset. Charset should be minimum 3 and maximum 8 character.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /name/{charset}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| charset | string | Yes | Character pattern for vessel names (3-8 chars, regex: `/^[0-9a-zA-Z-_.' ]+$/`) | `BINTANG` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | `BINTANG ABADI` |
| imoNumber | string | IMO number of vessel | `9232474` |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "vesselName": "BINTANG ABADI",
        "imoNumber": "9232474"
    },
    {
        "vesselName": "BINTANG ABADI"
        "imoNumber": "0"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/particulars/name/BINTANG' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the vessel name if it includes spaces or special characters.
- The API returns basic vessel particulars only (IMO number and vessel name).
- Ensure the `apikey` has sufficient access rights to call this endpoint.

---

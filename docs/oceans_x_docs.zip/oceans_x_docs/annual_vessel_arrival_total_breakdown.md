---
# Annual Vessel Arrival Total Breakdown

**UUID:** f32b7b05-d06d-4309-9c0f-2cc3363cbe89  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/f32b7b05-d06d-4309-9c0f-2cc3363cbe89  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/f32b7b05-d06d-4309-9c0f-2cc3363cbe89/documents/2c76891f-a6a0-4770-889b-8a029f66f0ff  
**Scraped:** 2026-04-26T04:11:26+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Distribution - Vessel Arrival Total Annual API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{DOMAIN}/api/vessel-arrival/1.0.0/annual-total-breakdown`  
**Update Frequency:** Monthly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides total annual vessel arrival statistics. Data is sourced from Data.gov.sg and updated monthly.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /annual-total-breakdown`

### 🔧 Path Parameters

*None*

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| startYear | string | Yes | Start year in YYYY format | `2018` |
| endYear | string | Yes | End year in YYYY format | `2024` |
| page | integer | No | Page number (1-indexed), minimum: 1 | `1` |
| size | integer | No | Number of records per page, minimum: 1, maximum: 100 | `20` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| items | array | Array of total vessel arrival records | See below (Items Array Item) |
| page | object | Pagination metadata | See below (Page Object) |
| \_links | object | Hypermedia links for navigation | See below (Links Object) |

**Items Array Item:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| year | integer | Year in YYYY format | 2023 |
| numberOfVessels | integer | Total number of vessels arrived in the year | 6420 |
| grossTonnage | number | Total gross tonnage for all vessels in the year | 218500000 |

**Page Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| number | integer | Current page number (1-indexed) | 1 |
| size | integer | Number of items per page | 3 |
| totalElements | integer | Total number of elements across all pages | 42 |
| totalPages | integer | Total number of pages | 14 |

**Links Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| self | object | Link to current page | `{"href": "/api/vessel-arrival/1.0.0/annual-total-breakdown?startYear=2023&endYear=2025&page=1&size=3"}` |
| prev | object | Link to previous page (if exists) | `{"href": "/api/vessel-arrival/1.0.0/annual-total-breakdown?startYear=2023&endYear=2025&page=1&size=3"}` |
| next | object | Link to next page (if exists) | `{"href": "/api/vessel-arrival/1.0.0/annual-total-breakdown?startYear=2023&endYear=2025&page=2&size=3"}` |

---

## 📤 **Response**

### ✅ HTTP Status Code: 200

```
{
  "items": [
    {
      "year": 2023,
      "numberOfVessels": 6420,
      "grossTonnage": 218500000
    },
    {
      "year": 2024,
      "numberOfVessels": 6850,
      "grossTonnage": 235800000
    },
    {
      "year": 2025,
      "numberOfVessels": 3250,
      "grossTonnage": 112400000
    }
  ],
  "page": {
    "number": 1,
    "size": 3,
    "totalElements": 42,
    "totalPages": 14
  },
  "_links": {
    "self": {
      "href": "/api/vessel-arrival/1.0.0/annual-total-breakdown?startYear=2023&endYear=2025&page=1&size=3"
    },
    "next": {
      "href": "/api/vessel-arrival/1.0.0/annual-total-breakdown?startYear=2023&endYear=2025&page=2&size=3"
    },
    "prev": {
      "href": "/api/vessel-arrival/1.0.0/annual-total-breakdown?startYear=2023&endYear=2025&page=1&size=3"
    }
  }
}
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
  "error": {
    "code": "400",
    "message": "Invalid or missing request parameters",
    "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
  }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/vessel-arrival/1.0.0/annual-total-breakdown?startYear=2018&endYear=2024&page=1&size=20' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Data is updated monthly.
- Results are paginated. Use `page` and `size` parameters to control pagination.

---

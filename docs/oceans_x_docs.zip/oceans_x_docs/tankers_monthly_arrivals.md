---
# Tankers Monthly Arrivals

**UUID:** 1c85873a-57dd-4f5f-a652-9c9775aec4ad  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/1c85873a-57dd-4f5f-a652-9c9775aec4ad  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/1c85873a-57dd-4f5f-a652-9c9775aec4ad/documents/a4cddc68-f681-4800-8a41-b6280699a7d9  
**Scraped:** 2026-04-26T05:18:59+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Tankers Monthly Arrivals (ZIP) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/staticdataset/tankerMonthlyArrivals`  
**Update Frequency:** Monthly

---

## 🔍 **Overview**

Provides the corresponding tankers monthly arrivals data in zip format.

---

## 📥 **Request**

### `GET /v1/staticdataset/tankerMonthlyArrivals`

No query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="tanker-arrivals-75-gt-monthly.zip"` |

#### Response Body:

Binary content of the ZIP file (`tanker-arrivals-75-gt-monthly.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/staticdataset/tankerMonthlyArrivals' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'tanker-arrivals-75-gt-monthly.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

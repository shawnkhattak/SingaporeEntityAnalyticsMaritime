---
# Vessel Type Data In Zipped CSV Format

**UUID:** 9d892560-02cd-4374-b3ec-50920b575eca  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/9d892560-02cd-4374-b3ec-50920b575eca  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/9d892560-02cd-4374-b3ec-50920b575eca/documents/386ae0a3-8627-43f4-ac5b-cb8722e30c5e  
**Scraped:** 2026-04-26T05:22:34+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Type Data (Zipped CSV) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/mdhvessel/reference/types/filetype/csvzip`  
**Update Frequency:** Daily  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessel type lookup data directly as a zipped CSV file.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /v1/mdhvessel/reference/types/filetype/csvzip`

No query parameters required.

---

## 🧾 **Response Details**

| Header | Type | Description | Example |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | application/zip |
| Content-Disposition | string | File attachment information | attachment; filename="VESSELTYPES\_REF\_CSV.zip" |

## 📤 **Response**

### ✅ 200 OK

The response returns the vessel type data directly as a zipped CSV file for download.

**Response Type:** Binary file (application/zip)  
**File Name:** VESSELTYPES\_REF\_CSV.zip  
**Content:** CSV file

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/mdhvessel/reference/types/filetype/csvzip' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- The response returns the zipped CSV file directly in the response body for immediate download.
- No request body or query parameters required.
- The ZIP file contains CSV data

---

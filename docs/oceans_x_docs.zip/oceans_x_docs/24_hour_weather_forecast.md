---
# 24-Hour Weather Forecast

**UUID:** 6341de7c-621c-4bfc-8b3c-f877d6e81d9c  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/6341de7c-621c-4bfc-8b3c-f877d6e81d9c  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/6341de7c-621c-4bfc-8b3c-f877d6e81d9c/documents/e5c05134-aa26-45c1-a543-ae32797e803b  
**Scraped:** 2026-04-26T04:11:07+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Weather - 24-Hour Forecast API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{DOMAIN}/api/weather/forecast/1.0.0/24hour-forecasts`  
**Update Frequency:** 6 hours  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Weather forecast for the next 24 hours. Data is retrieved from NEA’s open data API.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /forecast/24hour`

### 🔧 Path Parameters

*None*

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | No | SGT date for which to retrieve data (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS) | `2025-07-24` or `2025-07-24T11:30:00` |
| paginationToken | string | No | Pagination token for retrieving subsequent data pages (only exists when there is a next page available for requests with date filters) | `abc123` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| code | integer | Response status code (always 0 for success) | 0 |
| data | object | Weather forecast data object | See below (Data Object) |
| errorMsg | string | Error message (empty string for success) | "" |

**Data Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| records | array | List of forecast records | See below (Record Object) |
| paginationToken | string | Token to retrieve next page if exists | b2Zmc2V0PTEwMA== |

**Record Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| date | string | Date of forecast | 2025-07-24 |
| updatedTimestamp | string | Time of acquisition of data from NEA | 2025-07-24T11:41:00+08:00 |
| timestamp | string | Time forecast was issued by NEA | 2025-07-24T11:34:00+08:00 |
| general | object | A general weather forecast for the 24 hour period | See below (General Object) |
| periods | array | Forecasts for various areas in Singapore | See below (Period Object) |

**General Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| temperature | object | Unit of measure - Degrees Celsius | See below (Temperature Object) |
| relativeHumidity | object | Unit of measure - Percentage | See below (Relative Humidity Object) |
| forecast | object | Forecast code and text | See below (Forecast Object) |
| validPeriod | object | Period of time the forecast is valid for | See below (Valid Period Object) |
| wind | object | Wind speed and direction | See below (Wind Object) |

**Temperature Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| low | number | Lowest temperature | 25 |
| high | number | Highest temperature | 34 |
| unit | string | Unit of measure | Degrees Celsius |

**Relative Humidity Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| low | number | Lowest relative humidity | 50 |
| high | number | Highest relative humidity | 95 |
| unit | string | Unit of measure | Percentage |

**Forecast Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| code | string | Forecast code | PC |
| text | string | Forecast description | Partly Cloudy (Day) |

**Valid Period Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| start | string | Start of valid period | 2025-07-24T12:00:00+08:00 |
| end | string | End of valid period | 2025-07-25T12:00:00+08:00 |
| text | string | Human-readable period | 12 PM 24 Jul to 12 PM 25 Jul |

**Wind Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| speed | object | Unit of measure - Kilometres per hour | See below (Wind Speed Object) |
| direction | string | Wind direction | SSE |

**Wind Speed Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| low | number | Lowest wind speed | 10 |
| high | number | Highest wind speed | 20 |

**Period Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| timePeriod | object | Period of time the forecast is valid for | See below (Time Period Object) |
| regions | object | Forecasts for regions | See below (Region Object) |

**Time Period Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| start | string | Start of valid period | 2025-07-24T12:00:00+08:00 |
| end | string | End of valid period | 2025-07-24T18:00:00+08:00 |
| text | string | Human-readable period | Midday to 6 pm 24 Jul |

**Region Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| west | object | Forecast code and text for West | See below (Region Specific Object) |
| east | object | Forecast code and text for East | See below (Region Specific Object) |
| central | object | Forecast code and text for Central | See below (Region Specific Object) |
| south | object | Forecast code and text for South | See below (Region Specific Object) |
| north | object | Forecast code and text for North | See below (Region Specific Object) |

**Region Specific Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| code | string | Forecast code | PC |
| text | string | Forecast description | Partly Cloudy (Day) |

---

## 📤 **Response**

### ✅ HTTP Status Code: 200

```
{
  "code": 0,
  "data": {
    "records": [
      {
        "date": "2025-07-24",
        "updatedTimestamp": "2025-07-24T11:41:00+08:00",
        "timestamp": "2025-07-24T11:34:00+08:00",
        "general": {
          "temperature": {
            "low": 25,
            "high": 34,
            "unit": "Degrees Celsius"
          },
          "relativeHumidity": {
            "low": 50,
            "high": 95,
            "unit": "Percentage"
          },
          "forecast": {
            "code": "PC",
            "text": "Partly Cloudy (Day)"
          },
          "validPeriod": {
            "start": "2025-07-24T12:00:00+08:00",
            "end": "2025-07-25T12:00:00+08:00",
            "text": "12 PM 24 Jul to 12 PM 25 Jul"
          },
          "wind": {
            "speed": {
              "low": 10,
              "high": 20
            },
            "direction": "SSE"
          }
        },
        "periods": [
          {
            "timePeriod": {
              "start": "2025-07-24T12:00:00+08:00",
              "end": "2025-07-24T18:00:00+08:00",
              "text": "Midday to 6 pm 24 Jul"
            },
            "regions": {
              "west": {
                "code": "PC",
                "text": "Partly Cloudy (Day)"
              },
              "east": {
                "code": "PC",
                "text": "Partly Cloudy (Day)"
              },
              "central": {
                "code": "PC",
                "text": "Partly Cloudy (Day)"
              },
              "south": {
                "code": "PC",
                "text": "Partly Cloudy (Day)"
              },
              "north": {
                "code": "PC",
                "text": "Partly Cloudy (Day)"
              }
            }
          }
        ]
      }
    ],
    "paginationToken": "b2Zmc2V0PTEwMA=="
  },
  "errorMsg": ""
}
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
  "error": {
    "code": "400",
    "message": "Invalid or missing request parameters",
    "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
  }
}
```

### ❌ HTTP Status Code: 4xx/5xx from NEA:

```
{
  "code": 4,
  "name": "ERROR_PARAMS",
  "data": null,
  "errorMsg": "Invalid date format. Date format must be YYYY-MM-DD (2024-06-01) or YYYY-MM-DDTHH:mm:ss (2024-06-01T08:30:00)."
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/weather/forecast/1.0.0/24hour-forecasts?date=2025-07-24?date=2025-07-24' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Updated multiple times throughout the day
- Filter for specific date or date-time by providing date in query parameter:
  - Use `YYYY-MM-DD` format to retrieve all of the readings for that day
  - Use `YYYY-MM-DDTHH:mm:ss` to retrieve the latest readings at that moment in time
  - Example: `?date=2024-07-16` or `?date=2024-07-16T23:59:00`
- If date is not provided in query parameter, API will return the latest reading
- Possible values for `forecast` include:
  - Fair
  - Fair (Day)
  - Fair (Night)
  - Fair and Warm
  - Partly Cloudy
  - Partly Cloudy (Day)
  - Partly Cloudy (Night)
  - Cloudy
  - Hazy
  - Slightly Hazy
  - Windy
  - Mist
  - Fog
  - Light Rain
  - Moderate Rain
  - Heavy Rain
  - Passing Showers
  - Light Showers
  - Showers
  - Heavy Showers
  - Thundery Showers
  - Heavy Thundery Showers
  - Heavy Thundery Showers with Gusty Winds

---

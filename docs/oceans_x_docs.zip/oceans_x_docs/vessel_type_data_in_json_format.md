---
# Vessel Type Data In Json Format

**UUID:** 91703db9-06d4-4a14-9a50-c3861d4fbbf5  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/91703db9-06d4-4a14-9a50-c3861d4fbbf5  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/91703db9-06d4-4a14-9a50-c3861d4fbbf5/documents/79af0aa1-6dfd-4181-b5bd-4c37a8a0b4c0  
**Scraped:** 2026-04-26T05:22:27+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 Vessel Type Data (JSON) API

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/reference/types/filetype/json`  
**Update Frequency:** Daily  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 Overview

Provides the corresponding vessel type lookup data directly in JSON format.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /v1/mdhvessel/reference/types/filetype/json`

No query parameters required.

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| timeStamp | string | Timestamp of the data | "2014-04-14 00:00:00.000" |
| vesselTypeCode | string | Vessel type code | "BA" |
| vesselTypeDescription | string | Vessel type description | "BARGE" |

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "timeStamp": "2014-04-14 00:00:00.000",
        "vesselTypeCode": "BA",
        "vesselTypeDescription": "BARGE"
    },
    {
        "timeStamp": "2014-04-14 00:00:00.000",
        "vesselTypeCode": "BAAC",
        "vesselTypeDescription": "ACCOMMODATION/PIPE LAYING BARGE"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 Sample Curl Request

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/reference/types/filetype/json' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- The response returns the vessel type data directly as a JSON array in the response body.
- No request body or query parameters required.

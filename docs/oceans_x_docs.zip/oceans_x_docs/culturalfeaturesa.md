---
# CulturalFeaturesA

**UUID:** 7fe9205e-ddc6-4a4a-b64e-50e5cf2d3606  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/7fe9205e-ddc6-4a4a-b64e-50e5cf2d3606  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/7fe9205e-ddc6-4a4a-b64e-50e5cf2d3606/documents/dbc6945d-f45c-4dff-9f04-b85ff06b64e4  
**Scraped:** 2026-04-26T05:15:13+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Cultural Features (Area) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/culturalfeaturesa-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Polygon features to represent prominent objects at a fixed location, illustrating the area covered by this geographic object.

These polygon features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S-57).

This dataset is not to be used for navigation.

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/culturalfeaturesa-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_culturalfeaturesa.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_culturalfeaturesa.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/culturalfeaturesa-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_culturalfeaturesa.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

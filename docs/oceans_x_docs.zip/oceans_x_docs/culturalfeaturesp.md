---
# CulturalFeaturesP

**UUID:** 19e957ad-91db-4698-a4c1-e49099cc1f97  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/19e957ad-91db-4698-a4c1-e49099cc1f97  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/19e957ad-91db-4698-a4c1-e49099cc1f97/documents/1d885463-beb7-44c4-83bd-683c3ac6da75  
**Scraped:** 2026-04-26T05:15:28+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Cultural Features (Point) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/culturalfeaturesp-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Point features to represent prominent objects at a fixed location, illustrating the location of this geographic object.

These point features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S-57).

This dataset is not to be used for navigation.

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/culturalfeaturesp-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_culturalfeaturesp.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_culturalfeaturesp.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/culturalfeaturesp-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_culturalfeaturesp.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

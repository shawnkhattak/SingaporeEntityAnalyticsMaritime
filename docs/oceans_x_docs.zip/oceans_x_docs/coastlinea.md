---
# CoastlineA

**UUID:** 48e2c7a5-5079-44f0-b6cb-cc8da9631949  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/48e2c7a5-5079-44f0-b6cb-cc8da9631949  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/48e2c7a5-5079-44f0-b6cb-cc8da9631949/documents/2c291b1b-ff7f-4330-82c5-4905feb2ea64  
**Scraped:** 2026-04-26T05:14:59+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Coastline (Area) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/coastlinea-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Polygon features to represent the line where the shore and water meets, illustrating the area covered by this geographic object.

These polygon features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S-57).

This dataset is not to be used for navigation.

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/coastlinea-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_coastlinea.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_coastlinea.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/coastlinea-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_coastlinea.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

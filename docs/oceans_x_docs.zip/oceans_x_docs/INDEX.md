# OceansX API Documentation Index

Scraped: 2026-04-26T05:23:31+00:00 | Total: 110 | OK: 68 | Skipped: 14 | Cached: 28

| Name | UUID | File | Status |
|------|------|------|--------|
| 2-Hour Weather Forecast | c4034974-483f-4c42-b80b-6e82bd2cc7bf | 2_hour_weather_forecast.md | CACHED |
| 24-Hour Weather Forecast | 6341de7c-621c-4bfc-8b3c-f877d6e81d9c | 24_hour_weather_forecast.md | CACHED |
| 4-Days Weather Forecast | 2084ab03-247d-4ca1-b806-742cbdb47650 | 4_days_weather_forecast.md | CACHED |
| AidsToNavigationP | c7e495d8-1f75-469d-bb6d-4391176a2d19 | aidstonavigationp.md | CACHED |
| Annual Vessel Arrival Breakdown by Vessel Type | ac87cddb-02ac-4076-beac-8e84e8444902 | annual_vessel_arrival_breakdown_by_vessel_type.md | CACHED |
| Annual Vessel Arrival Total Breakdown | f32b7b05-d06d-4309-9c0f-2cc3363cbe89 | annual_vessel_arrival_total_breakdown.md | CACHED |
| Annual Vessel Call Volume | 49404a9e-9a08-4df7-8738-dd6042e31aed | annual_vessel_call_volume.md | CACHED |
| Bunkers Annual Sales | 27f65196-d862-42f0-8707-fe147bf407fe | bunkers_annual_sales.md | CACHED |
| Bunkers Monthly Sales | a0fb5847-7dc8-483e-9ec6-3be7c465aa1c | bunkers_monthly_sales.md | CACHED |
| Cargo Annual Throughput | 135eea5c-62a5-459e-88d0-58af4c4386c2 | cargo_annual_throughput.md | CACHED |
| Cargo Monthly Throughput | 71e9eacb-b866-41fb-83c0-d8a60b03a23b | cargo_monthly_throughput.md | CACHED |
| Coastal and Marine Habitat Map of Singapore 2018 | 110b63f5-d8f3-4d19-b15a-19ed5cf8ed4d | coastal_and_marine_habitat_map_of_singapore_2018.md | OK |
| CoastlineA | 48e2c7a5-5079-44f0-b6cb-cc8da9631949 | coastlinea.md | OK |
| CoastlineL | 9088bb99-4c57-42fb-a30e-4d0f72bec83c | coastlinel.md | OK |
| Container Annual Throughput | ee41ef52-a362-41ce-914e-e0bfe93f807c | container_annual_throughput.md | CACHED |
| Container Monthly Throughput | 005a55e8-39e1-4a49-986f-8787db025056 | container_monthly_throughput.md | CACHED |
| Country Codes Data In Json Format | 76e07728-2b3b-44f2-aec4-29059fa16f5b | country_codes_data_in_json_format.md | CACHED |
| Country Codes Data In Zipped CSV Format | 06467e5f-f3f1-4fca-868f-da5eafdffb0e | country_codes_data_in_zipped_csv_format.md | CACHED |
| Country Codes Data In Zipped Json Format | 5dc2dade-7796-4074-a126-631dcb10e114 | country_codes_data_in_zipped_json_format.md | CACHED |
| CulturalFeaturesA | 7fe9205e-ddc6-4a4a-b64e-50e5cf2d3606 | culturalfeaturesa.md | OK |
| CulturalFeaturesL | fb2fe8f3-a6ee-4177-93ea-b81d7fd5822f | culturalfeaturesl.md | OK |
| CulturalFeaturesP | 19e957ad-91db-4698-a4c1-e49099cc1f97 | culturalfeaturesp.md | OK |
| DangersA | 58d1f83e-e611-4223-98b2-83ad272892d3 | dangersa.md | OK |
| DangersL | 3a1dee46-c9ce-4c92-b2db-b7f1e5e59879 | dangersl.md | OK |
| DangersP | 91e00f4d-e0c9-44c3-9a4c-79bd9c46bee8 | dangersp.md | OK |
| DepthsA | 6fab286e-cc59-481c-b217-ffa3baee089e | depthsa.md | OK |
| DepthsL | 7b22c384-1bcc-4bd1-897c-0c52cc4c18f5 | depthsl.md | OK |
| Last Vessel Arrival Declaration by Vessel Name | 35149af0-867e-45b0-a4e6-c330d45d0c57 | last_vessel_arrival_declaration_by_vessel_name.md | CACHED |
| List of Vessel Particulars by name | 413d5064-b166-4a2a-b8e5-4c3383ba58e1 | list_of_vessel_particulars_by_name.md | CACHED |
| Location Codes Data In Json Format | 610677f1-d4d8-476e-bbef-1c5fa6525409 | location_codes_data_in_json_format.md | CACHED |
| Location Codes Data In Zipped CSV Format | 9e53c318-3e4f-4df6-b2d5-f5fb154774c7 | location_codes_data_in_zipped_csv_format.md | CACHED |
| Location Codes Data In Zipped Json Format | fb61ec28-052a-4035-8fe3-929f374cb7e7 | location_codes_data_in_zipped_json_format.md | CACHED |
| Master Plan 2019 SDCP Nature Boundary layer | 1ec73a09-5504-4b47-931c-aae0be808f47 | master_plan_2019_sdcp_nature_boundary_layer.md | OK |
| Master Plan 2019 SDCP Nature Boundary Line layer | 8e5e635f-bc06-41df-8602-195cb580d3c0 | master_plan_2019_sdcp_nature_boundary_line_layer.md | OK |
| Master Plan 2019 SDCP Park and Open Space layer | 23d2602c-691c-480a-ac6f-b8a0b5209f7e | master_plan_2019_sdcp_park_and_open_space_layer.md | OK |
| MilitaryFeaturesA | 821e6b98-8e1b-43ee-9bff-8575868a09ae | militaryfeaturesa.md | OK |
| Monthly Vessel Arrival Breakdown by Vessel Type | f862d10d-2b54-4192-81a2-fa83f7ab3d1d | monthly_vessel_arrival_breakdown_by_vessel_type.md | CACHED |
| Monthly Vessel Arrival Total Breakdown | f81f8e53-eee8-4aca-a225-3936144ba497 | monthly_vessel_arrival_total_breakdown.md | CACHED |
| Monthly Vessel Call Volume | 9645803f-8d64-43ad-a38b-0c31b1e305a1 | monthly_vessel_call_volume.md | CACHED |
| NaturalFeaturesA | bde91427-6fea-4628-88f9-88a28ca4a937 | naturalfeaturesa.md | OK |
| NaturalFeaturesL | 8387b032-1a72-4b74-a1bf-40a798e509ed | naturalfeaturesl.md | OK |
| NaturalFeaturesP | 8f80ecd4-52de-4b41-9600-a6a413e9c8a5 | naturalfeaturesp.md | OK |
| OffshoreInstallationsA | 01f891cc-49ec-4ba6-8b08-6b8923994441 | offshoreinstallationsa.md | OK |
| OffshoreInstallationsL | 1a7ab6d8-15dd-4c25-87c0-caa63f4c6a77 | offshoreinstallationsl.md | OK |
| Port Clearance Cert by CallSign | 256b8da5-9ba4-4857-8110-939ff97c4137 | port_clearance_cert_by_callsign.md | CACHED |
| Port Clearance Cert by IMO Number | 99f20df0-12f5-4f7d-880f-2f57cc7bab83 | port_clearance_cert_by_imo_number.md | CACHED |
| Port Clearance Cert by Vessel Name | 511e0ac6-8206-4fb6-b3ed-8f0fc1baa400 | port_clearance_cert_by_vessel_name.md | CACHED |
| Port Codes Data In Json Format | 952e3989-4db4-4366-a3fd-950e71db7279 | port_codes_data_in_json_format.md | CACHED |
| Port Codes Data In Zipped CSV Format | 25da913c-a147-4abc-a657-85cafaf36320 | port_codes_data_in_zipped_csv_format.md | OK |
| Port Codes Data In Zipped Json Format | f1b215e6-dbd4-4c58-afbf-8b0f7977af06 | port_codes_data_in_zipped_json_format.md | OK |
| PortsAndServicesA | d81a5dda-3106-499b-a29b-c80f77d30c8c | portsandservicesa.md | OK |
| PortsAndServicesL | bf7dd6e8-6c19-481e-b479-ec6a0f532db0 | portsandservicesl.md | OK |
| PortsAndServicesP | 75b75f0d-2c1c-4973-8e62-f8b33b1d55a1 | portsandservicesp.md | OK |
| Rainfall Readings | 64bc2970-43c7-4f5a-9d28-6a5a7c65166f | - | SKIPPED |
| RegulatedAreasAndLimitsA | b14a7204-d8e1-4bf2-98ed-eea6afd912c8 | - | SKIPPED |
| SeabedA | 203ce615-95b7-457c-87aa-a4e68cc81ebf | - | SKIPPED |
| SeabedP | d95150cf-504e-4ed4-83e2-efd48ae135bc | - | SKIPPED |
| Shipping Annual Tonnage | 012c710f-91e7-4e81-aad7-1059658f88a6 | shipping_annual_tonnage.md | OK |
| Shipping Monthly Tonnage | 31e51049-2089-4fe1-a65c-38f3daf0349f | shipping_monthly_tonnage.md | OK |
| Singaporean Chart SP1 Edition 1 | c246d474-e8b9-4fcb-b230-48eaa674596b | - | SKIPPED |
| Singaporean Chart SP1 Edition 2 | 5472e6c7-49ae-4c0c-ba7b-ea27655d5834 | - | SKIPPED |
| Singaporean Chart SP1 Edition 3 | 56172f5d-81e1-40fd-89d2-c0e22881cd3f | - | SKIPPED |
| Singaporean Chart SP1 Edition 4 | 2352e0aa-0003-4ec8-935b-4c84ac2c142e | - | SKIPPED |
| Singaporean Chart SP1 Edition 5 | bbf40677-7e99-467b-9f92-b4a278095005 | - | SKIPPED |
| SRS Certificate by Certificate Number | a50e5176-da0f-4d9e-aeaf-46e08b78d257 | srs_certificate_by_certificate_number.md | OK |
| SRS Certificate by Vessel Details | 47c673ee-6ffd-48f3-a7b3-b16571678d34 | srs_certificate_by_vessel_details.md | OK |
| Tankers Annual Arrivals | 101271b8-ff94-491a-80e1-8514451160b6 | tankers_annual_arrivals.md | OK |
| Tankers Monthly Arrivals | 1c85873a-57dd-4f5f-a652-9c9775aec4ad | tankers_monthly_arrivals.md | OK |
| TidesAndVariationsA | 3bcdae7b-154b-4a34-a46f-50acb0788a94 | - | SKIPPED |
| TidesAndVariationsP | 4fc0a84b-2e02-4a23-9059-07b744ba1b8f | - | SKIPPED |
| TracksAndRoutesA | 1a0fa819-b3a5-4541-9dfe-27b778ba1a49 | - | SKIPPED |
| TracksAndRoutesL | 3710a385-a50b-4483-be20-d97917605f94 | - | SKIPPED |
| TracksAndRoutesP | 5831ba38-a13e-40d4-960b-9eaca93fcfe3 | - | SKIPPED |
| Vessel Annual Calls | 3cbcea9f-cdcd-4969-913c-1450165a840b | vessel_annual_calls.md | OK |
| Vessel Arrival Declaration by CallSign | 38f1cb38-77bb-4e08-bba8-77e368753343 | vessel_arrival_declaration_by_callsign.md | OK |
| Vessel Arrival Declaration by Date | 831c10c6-ee32-40ec-ba8e-859cc3f305c7 | vessel_arrival_declaration_by_date.md | OK |
| Vessel Arrival Declaration by IMO Number | 971be21e-e039-41c7-9042-a1ea4a9f2105 | vessel_arrival_declaration_by_imo_number.md | OK |
| Vessel Arrival Declaration by Vessel Name | 1b3ae45c-9245-4dec-bce3-423810d2e8a8 | vessel_arrival_declaration_by_vessel_name.md | OK |
| Vessel Arrival Declaration for Past ‘N’ Hours | ca0ce2ae-e739-40a5-ae9e-fd7deed7a8dc | vessel_arrival_declaration_for_past_n_hours.md | OK |
| Vessel Arrivals by Date | 48bf4958-5970-4d53-932d-10f552bda64e | vessel_arrivals_by_date.md | OK |
| Vessel Arrivals for Past ‘N’ Hours | 40a78f10-1397-4fcd-9e12-d351d2aa6152 | vessel_arrivals_for_past_n_hours.md | OK |
| Vessel Departure Declaration by CallSign | ac5efca9-e894-43b7-a3f5-2836a06555c3 | vessel_departure_declaration_by_callsign.md | OK |
| Vessel Departure Declaration by Date | 6e7bfce1-f0a2-4045-be67-85a54660bc26 | vessel_departure_declaration_by_date.md | OK |
| Vessel Departure Declaration by IMO Number | 743c4889-1d03-4da7-a7d4-29b2de675839 | vessel_departure_declaration_by_imo_number.md | OK |
| Vessel Departure Declaration by Vessel Name | 60c59113-fd5e-4f5b-8f6e-1f10095ca0cb | vessel_departure_declaration_by_vessel_name.md | OK |
| Vessel Departure Declaration for Past ‘N’ Hours | 822731af-b870-407d-b719-2cdc39c196dc | vessel_departure_declaration_for_past_n_hours.md | OK |
| Vessel Departures by Date | 9e473ddd-1f2c-4807-8f3a-3756a0bed59f | vessel_departures_by_date.md | OK |
| Vessel Departures for Past ‘N’ Hours | f91dafc4-19bc-498a-bca1-989feab0b46a | vessel_departures_for_past_n_hours.md | OK |
| Vessel Monthly Calls | a4666f3c-ae11-442e-9fa3-e7bb5d6c2422 | vessel_monthly_calls.md | OK |
| Vessel Movements by CallSign | 6761b956-99c1-48bf-acc3-d3e7c8f31482 | vessel_movements_by_callsign.md | OK |
| Vessel Movements by IMO Number | cc722eba-f98f-4430-a482-066c4dff35d8 | vessel_movements_by_imo_number.md | OK |
| Vessel Movements by Name | 3ac09794-9094-470f-ad9a-05859935fb59 | vessel_movements_by_name.md | OK |
| Vessel Particulars by CallSign | 742fff87-5ae3-4ae2-a7c3-4a962c2a39d4 | vessel_particulars_by_callsign.md | OK |
| Vessel Particulars by IMO Number | 7e71547c-19d1-4435-918a-d3ec5d2ecbb8 | vessel_particulars_by_imo_number.md | OK |
| Vessel Particulars by Name | fd9f3ed8-0c62-431c-b2f8-d07383a3b824 | vessel_particulars_by_name.md | OK |
| Vessel Positions by CallSign | 4a9f9f18-d77a-4346-aaad-d6d1fbd6e59a | vessel_positions_by_callsign.md | OK |
| Vessel Positions by IMO Number | ed7d47cb-22d6-4d9d-bd16-f2f47503a81f | vessel_positions_by_imo_number.md | OK |
| Vessel Positions by Name | edd7c026-fa39-4d6e-8f07-2281680a59ba | vessel_positions_by_name.md | OK |
| Vessel Positions Snapshot | 1b2ee1ae-1693-4e34-873f-fbdcbb335ac9 | vessel_positions_snapshot.md | OK |
| Vessel Type Data In Json Format | 91703db9-06d4-4a14-9a50-c3861d4fbbf5 | vessel_type_data_in_json_format.md | OK |
| Vessel Type Data In Zipped CSV Format | 9d892560-02cd-4374-b3ec-50920b575eca | vessel_type_data_in_zipped_csv_format.md | OK |
| Vessel Type Data In Zipped Json Format | 615db028-d5e1-4627-ae53-9664ac8ba1c1 | vessel_type_data_in_zipped_json_format.md | OK |
| Vessels Annual Arrival | b7837d69-eb6a-4c66-8ddb-37186e9cdf68 | vessels_annual_arrival.md | OK |
| Vessels Due to Arrive by Date | 2228f8a0-6184-4d2d-a293-01ec2941752e | vessels_due_to_arrive_by_date.md | OK |
| Vessels Due to Arrive for Next ‘N’ Hours | a1aa3ea6-08e7-4763-858d-b9d9d968507d | vessels_due_to_arrive_for_next_n_hours.md | OK |
| Vessels Due to Depart by Date | dac77729-be46-46f5-847d-13db294a2542 | vessels_due_to_depart_by_date.md | OK |
| Vessels Due to Depart for Next ‘N’ Hours | 4426b135-80c2-46d0-b04f-4c2dfe26c394 | vessels_due_to_depart_for_next_n_hours.md | OK |
| Vessels Monthly Arrival | 694c0f29-25e4-4cb2-ba77-c167d2985ffe | vessels_monthly_arrival.md | OK |
| Wind Direction Readings | 7ea08341-9438-4510-980d-f10bc5e7eee2 | wind_direction_readings.md | OK |
| Wind Speed Readings | 52d70022-3cd5-46a0-8d40-9d8e5b33a92e | wind_speed_readings.md | OK |

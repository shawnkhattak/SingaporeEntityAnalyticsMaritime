---
# Country Codes Data In Json Format

**UUID:** 76e07728-2b3b-44f2-aec4-29059fa16f5b  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/76e07728-2b3b-44f2-aec4-29059fa16f5b  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/76e07728-2b3b-44f2-aec4-29059fa16f5b/documents/c82305f6-c532-456c-879e-86abc02dcaad  
**Scraped:** 2026-04-26T04:12:17+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Country Codes Data (JSON) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/mdhvessel/reference/countries/filetype/json`  
**Update Frequency:** Daily  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding country codes lookup data directly in JSON format.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /v1/mdhvessel/reference/countries/filetype/json`

No query parameters required.

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| nationality | string | Nationality of the country (can be empty) | "SCOTTISH" |
| timeStamp | string | Timestamp of the data | "2014-04-14 00:00:00.000" |
| countryCode | string | Country code | "04" |
| countryDescription | string | Country description | "SCOTLAND" |

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "nationality": "",
        "timeStamp": "2014-04-14 00:00:00.000",
        "countryCode": "01",
        "countryDescription": "NOT REGISTERED"
    },
    {
        "nationality": "SCOTTISH",
        "timeStamp": "2014-04-14 00:00:00.000",
        "countryCode": "04",
        "countryDescription": "SCOTLAND"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```

curl -X GET   
'https://{{DOMAIN}}/api/v1/mdhvessel/reference/countries/filetype/json'   
-H 'apikey: YOUR\_API\_KEY'

```

---

## 📎 Notes

- The response returns the country codes data directly as a JSON array in the response body.
- No request body or query parameters required.

---

---
# Bunkers Annual Sales

**UUID:** 27f65196-d862-42f0-8707-fe147bf407fe  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/27f65196-d862-42f0-8707-fe147bf407fe  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/27f65196-d862-42f0-8707-fe147bf407fe/documents/85c44696-6888-406f-8121-f61bf9a570ee  
**Scraped:** 2026-04-26T04:11:38+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Bunkers Annual Sales (ZIP) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/staticdataset/bunkerAnnualSales`  
**Update Frequency:** Annually

---

## 🔍 **Overview**

Provides the corresponding bunkers annual sales data in zip format.

---

## 📥 **Request**

### `GET /v1/staticdataset/bunkerAnnualSales`

No query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="bunker-sales-annual.zip"` |

#### Response Body:

Binary content of the ZIP file (`bunker-sales-annual.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X 'GET' \
  'https://{{DOMAIN}}/api/v1/staticdatasets/bunkerAnnualSales' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'bunker-sales-annual.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

---
# Vessels Due to Depart for Next ‘N’ Hours

**UUID:** 4426b135-80c2-46d0-b04f-4c2dfe26c394  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/4426b135-80c2-46d0-b04f-4c2dfe26c394  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/4426b135-80c2-46d0-b04f-4c2dfe26c394/documents/b20eb26e-1748-4f30-b60a-c3407c5d5a81  
**Scraped:** 2026-04-26T05:23:11+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessels Due to Depart for Next 'N' Hours API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/duetodepart/date/{date}/hours/{hours}`  
**Update Frequency:** 1 hour  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessels that are due to depart for the given date and time in yyyy-MM-dd HH:mm:ss format. The data is updated every hour

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /date/{date}/hours/{hours}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | Yes | Should be in date (yyyy-MM-dd HH:mm:ss) format | `2021-12-16 08:08:47` |
| hours | string | Yes | Number of hours to look ahead. Should be in number. | `10` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | KOTA GABUNG |
| callSign | string | Vessel call sign | VRQR3 |
| imoNumber | string | IMO number of the vessel | 9616852 |
| flag | string | Country flag of the vessel | HK |
| dueToDepart | string | Vessel due to depart time | 2021-12-16 15:00:00 |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "vesselParticulars": {
            "vesselName": "KOTA GABUNG",
            "callSign": "VRQR3",
            "imoNumber": "9616852",
            "flag": "HK"
        },
        "dueToDepart": "2021-12-16 15:00:00"
    },
    {
        "vesselParticulars": {
            "vesselName": "OCEANA BLUE",
            "callSign": "",
            "imoNumber": "0",
            "flag": "ID"
        },
        "dueToDepart": "2021-12-16 16:30:00"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/duetodepart/date/2021-12-16%2008:08:47/hours/10' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the date and time if needed.
- Ensure the `apikey` has sufficient access rights to call this endpoint.

---

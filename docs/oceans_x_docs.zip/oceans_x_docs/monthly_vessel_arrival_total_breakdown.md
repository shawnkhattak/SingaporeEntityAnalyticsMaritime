---
# Monthly Vessel Arrival Total Breakdown

**UUID:** f81f8e53-eee8-4aca-a225-3936144ba497  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/f81f8e53-eee8-4aca-a225-3936144ba497  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/f81f8e53-eee8-4aca-a225-3936144ba497/documents/42522508-f52d-4ac5-9120-25699e9bdd04  
**Scraped:** 2026-04-26T04:13:15+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Distribution - Vessel Arrival Total Monthly API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{DOMAIN}/api/vessel-arrival/1.0.0/monthly-total-breakdown`  
**Update Frequency:** Monthly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides total monthly vessel arrival statistics. Data is sourced from Data.gov.sg and updated monthly.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /monthly-total-breakdown`

### 🔧 Path Parameters

*None*

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| startMonth | string | Yes | Start month in YYYY-MM format | `2014-03` |
| endMonth | string | Yes | End month in YYYY-MM format | `2017-08` |
| page | integer | No | Page number (1-indexed), minimum: 1 | `1` |
| size | integer | No | Number of records per page, minimum: 1, maximum: 100 | `20` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| items | array | Array of total vessel arrival records | See below (Items Array Item) |
| page | object | Pagination metadata | See below (Page Object) |
| \_links | object | Hypermedia links for navigation | See below (Links Object) |

**Items Array Item:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| month | string | Month in YYYY-MM format | "2025-05" |
| numberOfVessels | integer | Total number of vessels arrived in the month | 542 |
| grossTonnage | number | Total gross tonnage for all vessels in the month | 18750000 |

**Page Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| number | integer | Current page number (1-indexed) | 1 |
| size | integer | Number of items per page | 3 |
| totalElements | integer | Total number of elements across all pages | 42 |
| totalPages | integer | Total number of pages | 14 |

**Links Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| self | object | Link to current page | `{"href": "/api/vessel-arrival/1.0.0/monthly-total-breakdown?startMonth=2025-05&endMonth=2025-07&page=1&size=3"}` |
| prev | object | Link to previous page (if exists) | `{"href": "/api/vessel-arrival/1.0.0/monthly-total-breakdown?startMonth=2025-05&endMonth=2025-07&page=1&size=3"}` |
| next | object | Link to next page (if exists) | `{"href": "/api/vessel-arrival/1.0.0/monthly-total-breakdown?startMonth=2025-05&endMonth=2025-07&page=2&size=3"}` |

---

## 📤 **Response**

### ✅ HTTP Status Code: 200

```
{
  "items": [
    {
      "month": "2025-05",
      "numberOfVessels": 542,
      "grossTonnage": 18750000
    },
    {
      "month": "2025-06",
      "numberOfVessels": 578,
      "grossTonnage": 19850000
    },
    {
      "month": "2025-07",
      "numberOfVessels": 521,
      "grossTonnage": 18200000
    }
  ],
  "page": {
    "number": 1,
    "size": 3,
    "totalElements": 42,
    "totalPages": 14
  },
  "_links": {
    "self": {
      "href": "/api/vessel-arrival/1.0.0/monthly-total-breakdown?startMonth=2025-05&endMonth=2025-07&page=1&size=3"
    },
    "next": {
      "href": "/api/vessel-arrival/1.0.0/monthly-total-breakdown?startMonth=2025-05&endMonth=2025-07&page=2&size=3"
    },
    "prev": {
      "href": "/api/vessel-arrival/1.0.0/monthly-total-breakdown?startMonth=2025-05&endMonth=2025-07&page=1&size=3"
    }
  }
}
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
  "error": {
    "code": "400",
    "message": "Invalid or missing request parameters",
    "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
  }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/vessel-arrival/1.0.0/monthly-total-breakdown?startMonth=2014-03&endMonth=2017-08&page=1&size=20' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Data is updated monthly.
- Results are paginated. Use `page` and `size` parameters to control pagination.

---

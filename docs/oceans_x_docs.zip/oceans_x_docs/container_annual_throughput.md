---
# Container Annual Throughput

**UUID:** ee41ef52-a362-41ce-914e-e0bfe93f807c  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/ee41ef52-a362-41ce-914e-e0bfe93f807c  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/ee41ef52-a362-41ce-914e-e0bfe93f807c/documents/ddc72e77-d5b5-4f12-8136-669eed211ca2  
**Scraped:** 2026-04-26T04:12:04+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Container Annual Throughput (ZIP) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/staticdataset/containerAnnualThroughput`  
**Update Frequency:** Annually

---

## 🔍 **Overview**

Provides the corresponding container annual throughput data in zip format.

---

## 📥 **Request**

### `GET /v1/staticdataset/containerAnnualThroughput`

No query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="container-throughput-annual.zip"` |

#### Response Body:

Binary content of the ZIP file (`container-throughput-annual.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/staticdataset/containerAnnualThroughput' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'container-throughput-annual.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

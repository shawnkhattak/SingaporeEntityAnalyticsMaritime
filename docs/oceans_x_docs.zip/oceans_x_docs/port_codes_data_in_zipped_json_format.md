---
# Port Codes Data In Zipped Json Format

**UUID:** f1b215e6-dbd4-4c58-afbf-8b0f7977af06  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/f1b215e6-dbd4-4c58-afbf-8b0f7977af06  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/f1b215e6-dbd4-4c58-afbf-8b0f7977af06/documents/bed69927-6e62-4456-a390-635a0b443e9e  
**Scraped:** 2026-04-26T05:17:16+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Port Codes Data (Zipped JSON) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/mdhvessel/reference/ports/filetype/jsonzip`  
**Update Frequency:** Daily  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding port codes lookup data directly as a zipped JSON file.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /v1/mdhvessel/reference/ports/filetype/jsonzip`

No query parameters required.

---

## 🧾 **Response Details**

| Header | Type | Description | Example |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | application/zip |
| Content-Disposition | string | File attachment information | attachment; filename="PORTS\_REF\_JSON.zip" |

## 📤 **Response**

### ✅ 200 OK

The response returns the port codes data directly as a zipped JSON file for download.

**Response Type:** Binary file (application/zip)  
**File Name:** PORTS\_REF\_JSON.zip  
**Content:** JSON file

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/mdhvessel/reference/ports/filetype/jsonzip' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- The response returns the zipped JSON file directly in the response body for immediate download.
- No request body or query parameters required.
- The ZIP file contains JSON data

---

---
# PortsAndServicesP

**UUID:** 75b75f0d-2c1c-4973-8e62-f8b33b1d55a1  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/75b75f0d-2c1c-4973-8e62-f8b33b1d55a1  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/75b75f0d-2c1c-4973-8e62-f8b33b1d55a1/documents/97359ef8-c3b4-41c7-8e82-8d7c7221081e  
**Scraped:** 2026-04-26T05:17:37+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Ports and Services (Point) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/portsandservicesp-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Point features to represent structures that support port operations, illustrating the location of this geographic object.

These point features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S-57).

This dataset is not to be used for navigation.

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/portsandservicesp-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_portsandservicesp.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_portsandservicesp.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/portsandservicesp-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_portsandservicesp.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

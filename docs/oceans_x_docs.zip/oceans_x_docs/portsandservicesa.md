---
# PortsAndServicesA

**UUID:** d81a5dda-3106-499b-a29b-c80f77d30c8c  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/d81a5dda-3106-499b-a29b-c80f77d30c8c  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/d81a5dda-3106-499b-a29b-c80f77d30c8c/documents/7532c6bb-cdba-4c99-8165-ba8ef92db65c  
**Scraped:** 2026-04-26T05:17:23+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Ports and Services (Area) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/portsandservicesa-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Polygon features to represent structures that support port operations, illustrating the area covered by this geographic object.

These polygon features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S-57).

This dataset is not to be used for navigation.

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/portsandservicesa-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_portsandservicesa.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_portsandservicesa.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/portsandservicesa-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_portsandservicesa.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

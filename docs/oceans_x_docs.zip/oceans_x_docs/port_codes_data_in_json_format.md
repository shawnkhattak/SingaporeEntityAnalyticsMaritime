---
# Port Codes Data In Json Format

**UUID:** 952e3989-4db4-4366-a3fd-950e71db7279  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/952e3989-4db4-4366-a3fd-950e71db7279  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/952e3989-4db4-4366-a3fd-950e71db7279/documents/f6b3dc03-98fe-4088-bcdf-773d4c2b55cc  
**Scraped:** 2026-04-26T04:13:48+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Port Codes Data (JSON) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/mdhvessel/reference/ports/filetype/json`  
**Update Frequency:** Daily  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding port codes lookup data directly in JSON format.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /v1/mdhvessel/reference/ports/filetype/json`

No query parameters required.

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| portCode | string | Port code | "ADZZZ" |
| portDescription | string | Port description | "O P ANDORRA" |
| timeStamp | string | Timestamp of the data | "2014-04-14 00:00:00.000" |

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "portCode": "ADZZZ",
        "portDescription": "O P ANDORRA",
        "timeStamp": "2014-04-14 00:00:00.000"
    },
    {
        "portCode": "AEAJM",
        "portDescription": "AJMAN",
        "timeStamp": "2014-04-14 00:00:00.000"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/mdhvessel/reference/ports/filetype/json' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- The response returns the port codes data directly as a JSON array in the response body.
- No request body or query parameters required.

---

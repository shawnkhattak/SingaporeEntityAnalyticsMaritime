---
# Vessel Departure Declaration for Past ‘N’ Hours

**UUID:** 822731af-b870-407d-b719-2cdc39c196dc  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/822731af-b870-407d-b719-2cdc39c196dc  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/822731af-b870-407d-b719-2cdc39c196dc/documents  
**Scraped:** 2026-04-26T05:20:54+00:00

---

​

​

## API Documentation

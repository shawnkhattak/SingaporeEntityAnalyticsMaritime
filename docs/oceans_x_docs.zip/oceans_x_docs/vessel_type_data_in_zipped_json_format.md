---
# Vessel Type Data In Zipped Json Format

**UUID:** 615db028-d5e1-4627-ae53-9664ac8ba1c1  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/615db028-d5e1-4627-ae53-9664ac8ba1c1  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/615db028-d5e1-4627-ae53-9664ac8ba1c1/documents/6c22e050-8f00-486f-a51e-32de5758ec83  
**Scraped:** 2026-04-26T05:22:40+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Type Data (Zipped JSON) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/mdhvessel/reference/types/filetype/jsonzip`  
**Update Frequency:** Daily  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessel type lookup data directly as a zipped JSON file.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /v1/mdhvessel/reference/types/filetype/jsonzip`

No query parameters required.

---

## 🧾 **Response Details**

| Header | Type | Description | Example |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | application/zip |
| Content-Disposition | string | File attachment information | attachment; filename="VESSELTYPES\_REF\_JSON.zip" |

## 📤 **Response**

### ✅ 200 OK

The response returns the vessel type data directly as a zipped JSON file for download.

**Response Type:** Binary file (application/zip)  
**File Name:** VESSELTYPES\_REF\_JSON.zip  
**Content:** JSON file

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/mdhvessel/reference/types/filetype/jsonzip' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- The response returns the zipped JSON file directly in the response body for immediate download.
- No request body or query parameters required.
- The ZIP file contains JSON data

---

---
# Vessel Arrivals by Date

**UUID:** 48bf4958-5970-4d53-932d-10f552bda64e  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/48bf4958-5970-4d53-932d-10f552bda64e  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/48bf4958-5970-4d53-932d-10f552bda64e/documents/f340b5dc-94e3-4d6a-aa37-85428259d8ae  
**Scraped:** 2026-04-26T05:20:08+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Arrivals by Date API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/arrivals/date/{date}`  
**Update Frequency:** 1 hour  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessels arrival information for the given date in yyyy-MM-dd format. The data is updated every hour.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /date/{date}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | Yes | Should be in date (yyyy-MM-dd) format | `2025-08-30` |

### 🔧 Query Parameters

*None*

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars object | {...} |
| arrivedTime | string | Arrival time (YYYY-MM-DD HH:MM:SS) | 2025-08-30 00:00:00 |
| locationFrom | string | Location from | SEAW |
| locationTo | string | Location to | PEBGB |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | NORD AQUARIUS |
| callSign | string | Vessel call sign | 3E2118 |
| imoNumber | string | IMO number of the vessel | 9941398 |
| flag | string | Vessel flag | PA |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "vesselParticulars": {
            "vesselName": "NORD AQUARIUS",
            "callSign": "3E2118",
            "imoNumber": "9941398",
            "flag": "PA"
        },
        "arrivedTime": "2025-08-30 00:00:00",
        "locationFrom": "SEAW",
        "locationTo": "PEBGB"
    },
    {
        "vesselParticulars": {
            "vesselName": "VIS",
            "callSign": "3E8951",
            "imoNumber": "9931862",
            "flag": "PA"
        },
        "arrivedTime": "2025-08-30 00:00:00",
        "locationFrom": "SEAE",
        "locationTo": "PGBG"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/arrivals/date/2025-08-30' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the date if needed.
- The API returns arrival data for the specified date.
- Ensure the `apikey` has sufficient access rights to call this endpoint.

---

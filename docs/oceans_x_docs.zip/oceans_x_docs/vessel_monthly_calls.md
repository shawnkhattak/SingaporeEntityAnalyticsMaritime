---
# Vessel Monthly Calls

**UUID:** a4666f3c-ae11-442e-9fa3-e7bb5d6c2422  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/a4666f3c-ae11-442e-9fa3-e7bb5d6c2422  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/a4666f3c-ae11-442e-9fa3-e7bb5d6c2422/documents/d7dd5686-5a8a-4bbc-bc1b-8d566ea7411a  
**Scraped:** 2026-04-26T05:21:17+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Monthly Calls (ZIP) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/staticdataset/vesselMonthlyCalls`  
**Update Frequency:** Monthly

---

## 🔍 **Overview**

Provides the corresponding vessel monthly calls data in zip format.

---

## 📥 **Request**

### `GET /v1/staticdataset/vesselMonthlyCalls`

No query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="vessel-calls-75-gt-monthly.zip"` |

#### Response Body:

Binary content of the ZIP file (`vessel-calls-75-gt-monthly.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/staticdataset/vesselMonthlyCalls' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'vessel-calls-75-gt-monthly.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

---
# Vessels Due to Arrive by Date

**UUID:** 2228f8a0-6184-4d2d-a293-01ec2941752e  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/2228f8a0-6184-4d2d-a293-01ec2941752e  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/2228f8a0-6184-4d2d-a293-01ec2941752e/documents/5a4792e3-9b06-4183-ab76-0ec69c5fd526  
**Scraped:** 2026-04-26T05:22:52+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessels Due to Arrive by Date API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/duetoarrive/date/{date}`  
**Update Frequency:** 1 hour  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessels that are due to arrive information for the given date in yyyy-MM-dd format. The data is updated every hour

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /date/{date}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | Yes | Should be in date (yyyy-MM-dd) format | `2025-08-30` |

### 🔧 Query Parameters

*None*

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars object | {...} |
| duetoArriveTime | string | Due to arrive time (YYYY-MM-DD HH:MM:SS) | 2025-08-30 05:30:00 |
| locationFrom | string | Location from | SEA |
| locationto | string | Location to | PWBGB |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | MSC DIEGO |
| callSign | string | Vessel call sign | 3FZP8 |
| imoNumber | string | IMO number of the vessel | 9202649 |
| flag | string | Vessel flag | PA |

---

## 📤 **Response**

### ✅ 200 OK

```
[
  {
    "vesselParticulars": {
      "vesselName": "MSC DIEGO",
      "callSign": "3FZP8",
      "imoNumber": "9202649",
      "flag": "PA"
    },
    "duetoArriveTime": "2025-08-30 05:30:00",
    "locationFrom": "SEA",
    "locationTo": "PWBGB"
  }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/duetoarrive/date/2025-08-30' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the date if needed.
- The API returns vessels due to arrive for the specified date.
- Ensure the `apikey` has sufficient access rights to call this endpoint.

---

---
# Vessel Departure Declaration by Vessel Name

**UUID:** 60c59113-fd5e-4f5b-8f6e-1f10095ca0cb  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/60c59113-fd5e-4f5b-8f6e-1f10095ca0cb  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/60c59113-fd5e-4f5b-8f6e-1f10095ca0cb/documents  
**Scraped:** 2026-04-26T05:20:44+00:00

---

​

​

## API Documentation

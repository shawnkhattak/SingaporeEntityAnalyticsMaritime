---
# Monthly Vessel Arrival Breakdown by Vessel Type

**UUID:** f862d10d-2b54-4192-81a2-fa83f7ab3d1d  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/f862d10d-2b54-4192-81a2-fa83f7ab3d1d  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/f862d10d-2b54-4192-81a2-fa83f7ab3d1d/documents/4c027b2a-bbb9-4f3c-8bb3-1c6bcb08d984  
**Scraped:** 2026-04-26T04:13:09+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Distribution - Vessel Arrivals Breakdown Monthly API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{DOMAIN}/api/vessel-arrival/1.0.0/monthly-vessel-type-breakdown`  
**Update Frequency:** Monthly  
**Authentication:** `API Key` (via `apikey` header)

---

## 📄 Overview

Provides monthly vessel arrival statistics, with breakdown by vessel type. Data is sourced from Data.gov.sg and updated monthly.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 Request

### `GET /monthly-vessel-type-breakdown`

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| startMonth | string | Yes | Start month in YYYY-MM format | `2010-05` |
| endMonth | string | Yes | End month in YYYY-MM format | `2014-08` |
| vesselType | string | No | Vessel type filter (see below) | `Tug` |
| page | integer | No | Page number (1-indexed), minimum: 1 | `1` |
| size | integer | No | Number of records per page, minimum: 1, maximum: 100 | `20` |

**Accepted Values for vesselType:**

- Tug
- Barges
- Tanker
- Container
- Freighter
- Passenger
- Bulk
- Carrier
- Miscellaneous

---

## 🧾 Response Details

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| items | array | Array of vessel arrival breakdown records | See below (Items Array Item) |
| page | object | Pagination metadata | See below (Page Object) |
| \_links | object | Hypermedia links for navigation | See below (Links Object) |

**Items Array Item:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| month | string | Month in YYYY-MM format | "2025-05" |
| vesselType | string | Type of vessel | "Tanker" |
| numberOfVessels | integer | Number of vessels arrived for the vessel type | 89 |
| grossTonnage | number | Total gross tonnage for the vessel type | 4250000 |

**Page Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| number | integer | Current page number (1-indexed) | 1 |
| size | integer | Number of items per page | 3 |
| totalElements | integer | Total number of elements across all pages | 42 |
| totalPages | integer | Total number of pages | 14 |

**Links Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| self | object | Link to current page | `{"href": "/api/vessel-arrival/1.0.0/monthly-vessel-type-breakdown?startMonth=2025-05&endMonth=2025-07&page=1&size=3"}` |
| prev | object | Link to previous page (if exists) | `{"href": "/api/vessel-arrival/1.0.0/monthly-vessel-type-breakdown?startMonth=2025-05&endMonth=2025-07&page=1&size=3"}` |
| next | object | Link to next page (if exists) | `{"href": "/api/vessel-arrival/1.0.0/monthly-vessel-type-breakdown?startMonth=2025-05&endMonth=2025-07&page=2&size=3"}` |

---

## 📤 **Response**

### ✅ HTTP Status Code: 200

```
{
  "items": [
    {
      "month": "2025-05",
      "vesselType": "Tanker",
      "numberOfVessels": 89,
      "grossTonnage": 4250000
    },
    {
      "month": "2025-06",
      "vesselType": "Tanker",
      "numberOfVessels": 94,
      "grossTonnage": 4680000
    },
    {
      "month": "2025-07",
      "vesselType": "Tanker",
      "numberOfVessels": 87,
      "grossTonnage": 4120000
    }
  ],
  "page": {
    "number": 1,
    "size": 3,
    "totalElements": 42,
    "totalPages": 14
  },
  "_links": {
    "self": {
      "href": "/api/vessel-arrival/1.0.0/monthly-vessel-type-breakdown?startMonth=2025-05&endMonth=2025-07&page=1&size=3"
    },
    "next": {
      "href": "/api/vessel-arrival/1.0.0/monthly-vessel-type-breakdown?startMonth=2025-05&endMonth=2025-07&page=2&size=3"
    },
    "prev": {
      "href": "/api/vessel-arrival/1.0.0/monthly-vessel-type-breakdown?startMonth=2025-05&endMonth=2025-07&page=1&size=3"
    }
  }
}
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
  "error": {
    "code": "400",
    "message": "Invalid or missing request parameters",
    "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
  }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/vessel-arrival/1.0.0/monthly-vessel-type-breakdown?startMonth=2010-05&endMonth=2014-08&page=1&size=20' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Data is updated monthly.
- If `vesselType` is not provided, all vessel types will be included in the response.
- Results are paginated. Use `page` and `size` parameters to control pagination.

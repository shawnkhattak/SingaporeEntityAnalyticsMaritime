---
# Port Clearance Cert by IMO Number

**UUID:** 99f20df0-12f5-4f7d-880f-2f57cc7bab83  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/99f20df0-12f5-4f7d-880f-2f57cc7bab83  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/99f20df0-12f5-4f7d-880f-2f57cc7bab83/documents/255ff78c-19c8-4402-aa85-9458a658d6f2  
**Scraped:** 2026-04-26T04:13:35+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Port Clearance Certificate by IMO Number API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/portclearance/imonumber/{imonumber}`  
**Update Frequency:** Hourly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding port clearance cert information for the given vessel IMO number. The data is updated every hour.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /imonumber/{imonumber}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| imonumber | string | Yes | IMO number of vessel | 9762156 |

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| gdvno | string | Yes | GDV number of the vessel | 850524 |
| certificateno | string | Yes | Alphanumeric certificate ID | E84204 |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel information object | {...} |
| certificateNumber | string | Certificate number | E84204 |
| status | string | Status | 1 |
| gdvNumber | string | GDV number of the certificate | 850524 |
| grossTonnage | number | Gross tonnage | 719 |
| cargo | number | Cargo | 380 |
| nextPortOfCall | string | Next port of call | JAKARTA, JAVA |
| nextPortOfCallCountry | string | Next port of call country | ID |
| dateAndTimeOfDeparture | string | Date and time of departure | 2025-08-30 21:00:00 |
| dateAndTimeOfIssue | string | Date and time of certificate issue | 2025-08-30 18:27:27 |
| expiryDateAndTimeOfPortCertificate | string | Expiry date and time of port certificate | 2025-09-01 18:26:27 |
| nameOfMaster | string | Master name | DARWIN LUTHAN MAHMUD |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | RADJA SAMUDERA ABADI |
| callSign | string | CallSign of the vessel | PKJQ |
| imoNumber | string | IMO number of the vessel | 9762156 |
| flag | string | Country flag of the vessel | ID |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "vesselParticulars": {
            "vesselName": "RADJA SAMUDERA ABADI",
            "callSign": "PKJQ",
            "imoNumber": "9762156",
            "flag": "ID"
        },
        "certificateNumber": "E84204",
        "status": "1",
        "gdvNumber": "850524",
        "grossTonnage": 719,
        "cargo": 380,
        "nextPortOfCall": "JAKARTA, JAVA",
        "nextPortOfCallCountry": "ID",
        "dateAndTimeOfDeparture": "2025-08-30 21:00:00",
        "dateAndTimeOfIssue": "2025-08-30 18:27:27",
        "expiryDateAndTimeOfPortCertificate": "2025-09-01 18:26:27",
        "nameOfMaster": "DARWIN LUTHAN MAHMUD"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/portclearance/imonumber/9762156?gdvno=850524&certificateno=E84204' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the IMO number if it includes special characters.
- The API supports **hourly refreshed** data from the Maritime Data Hub.

---

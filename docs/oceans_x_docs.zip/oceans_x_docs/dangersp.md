---
# DangersP

**UUID:** 91e00f4d-e0c9-44c3-9a4c-79bd9c46bee8  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/91e00f4d-e0c9-44c3-9a4c-79bd9c46bee8  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/91e00f4d-e0c9-44c3-9a4c-79bd9c46bee8/documents/52a93a51-213c-49ca-ae1e-d70a30742a1b  
**Scraped:** 2026-04-26T05:15:48+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Dangers (Point) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/dangersp-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Point features to represent objects/items that have been made aware to mariners that influence their safety of navigation and this includes Rocks, Coral Reefs, Wrecks etc., illustrating the location of this geographic object.

These point features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S-57).

This dataset is not to be used for navigation.

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/dangersp-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_dangersp.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_dangersp.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/dangersp-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_dangersp.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

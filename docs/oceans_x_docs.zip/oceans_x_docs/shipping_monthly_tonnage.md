---
# Shipping Monthly Tonnage

**UUID:** 31e51049-2089-4fe1-a65c-38f3daf0349f  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/31e51049-2089-4fe1-a65c-38f3daf0349f  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/31e51049-2089-4fe1-a65c-38f3daf0349f/documents/2ea7fa27-b228-4cc6-a991-af122263d1c6  
**Scraped:** 2026-04-26T05:18:11+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Shipping Monthly Tonnage (ZIP) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/staticdataset/vesselShippingMonthlyTonnage`  
**Update Frequency:** Monthly

---

## 🔍 **Overview**

Provides the corresponding shipping monthly tonnage data in zip format.

---

## 📥 **Request**

### `GET /v1/staticdataset/vesselShippingMonthlyTonnage`

No query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="registered-vessels-and-shipping-tonnage-monthly.zip"` |

#### Response Body:

Binary content of the ZIP file (`registered-vessels-and-shipping-tonnage-monthly.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/staticdataset/vesselShippingMonthlyTonnage' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'registered-vessels-and-shipping-tonnage-monthly.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

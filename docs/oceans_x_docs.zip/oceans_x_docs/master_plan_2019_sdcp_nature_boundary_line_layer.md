---
# Master Plan 2019 SDCP Nature Boundary Line layer

**UUID:** 8e5e635f-bc06-41df-8602-195cb580d3c0  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/8e5e635f-bc06-41df-8602-195cb580d3c0  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/8e5e635f-bc06-41df-8602-195cb580d3c0/documents/b9fc86e1-f17a-467b-a0ca-b15945e60235  
**Scraped:** 2026-04-26T05:16:16+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Master Plan Nature Boundary Line Layer API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/ura/master-plan-nature-boundary-line-layer`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Provides access to the URA Master Plan Nature Boundary Line Layer dataset. This API returns a reference URL to the data.gov.sg portal where the dataset collection can be accessed and downloaded.

---

## 📥 **Request**

### `GET /v1/gssdataset/ura/master-plan-nature-boundary-line-layer`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response contains a JSON object with a `location` field pointing to the data.gov.sg collection page.

#### Response Body:

```
{
    "location": "https://data.gov.sg/collections/1734/view"
}
```

#### Response Fields:

| Field | Type | Description |
| --- | --- | --- |
| location | string | URL to the data.gov.sg collection page where the Master Plan Nature Boundary Line Layer dataset can be accessed and downloaded |

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/ura/master-plan-nature-boundary-line-layer' \
  -H 'ApiKey: YOUR_API_KEY'
```

---

## 📎 Notes

- The API returns a reference URL to data.gov.sg, not the actual dataset file.
- Users should navigate to the provided URL to access and download the dataset from data.gov.sg.
- No request body or query parameters required.

---

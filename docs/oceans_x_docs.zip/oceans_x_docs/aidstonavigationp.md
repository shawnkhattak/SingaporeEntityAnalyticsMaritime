---
# AidsToNavigationP

**UUID:** c7e495d8-1f75-469d-bb6d-4391176a2d19  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/c7e495d8-1f75-469d-bb6d-4391176a2d19  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/c7e495d8-1f75-469d-bb6d-4391176a2d19/documents/185f11c1-8169-4750-9573-9fc3161db43a  
**Scraped:** 2026-04-26T04:18:26+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Aids to Navigation API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/aidstonavigationp-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Point features representing floating or fixed structures carrying equipment objects as an aid to navigation for vessels and mariners, illustrating the location of this geographic object.

These point features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S-57).

This dataset is not to be used for navigation.

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/aidstonavigationp-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_aidstonavigationp.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_aidstonavigationp.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/aidstonavigationp-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_aidstonavigationp.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

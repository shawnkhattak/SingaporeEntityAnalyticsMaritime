---
# Location Codes Data In Json Format

**UUID:** 610677f1-d4d8-476e-bbef-1c5fa6525409  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/610677f1-d4d8-476e-bbef-1c5fa6525409  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/610677f1-d4d8-476e-bbef-1c5fa6525409/documents/041a9c8e-3e91-44b9-94d5-f748790531d0  
**Scraped:** 2026-04-26T04:12:50+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Location Codes Data (JSON) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/mdhvessel/reference/locations/filetype/json`  
**Update Frequency:** Daily  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding location codes lookup data directly in JSON format.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /v1/mdhvessel/reference/locations/filetype/json`

No query parameters required.

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| timeStamp | string | Timestamp of the data | "2024-05-27 21:32:55.313" |
| locationCode | string | Location code | "ABBL1" |
| locationDescription | string | Location description | "BREAK BULK LOT1(0319C)" |

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "timeStamp": "2024-05-27 21:32:55.313",
        "locationCode": "ABBL1",
        "locationDescription": "BREAK BULK LOT1(0319C)"
    },
    {
        "timeStamp": "2002-05-02 17:13:39.447",
        "locationCode": "ACBTH",
        "locationDescription": "CHANGI TEMP HOLDG ANCH"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/mdhvessel/reference/locations/filetype/json' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- The response returns the location codes data directly as a JSON array in the response body.
- No request body or query parameters required.

---

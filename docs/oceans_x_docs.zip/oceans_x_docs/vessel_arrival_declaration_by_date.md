---
# Vessel Arrival Declaration by Date

**UUID:** 831c10c6-ee32-40ec-ba8e-859cc3f305c7  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/831c10c6-ee32-40ec-ba8e-859cc3f305c7  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/831c10c6-ee32-40ec-ba8e-859cc3f305c7/documents/e07abef1-1ebb-4a70-85d7-e70084d09e29  
**Scraped:** 2026-04-26T05:19:42+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Arrival Declaration by Date API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/arrivaldeclaration/bydate?date={date}`  
**Update Frequency:** Hourly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessel arrival declaration information for the given date. The data is updated every hour

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /bydate?date={date}`

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | Yes | Date in `yyyy-MM-dd` format | `2024-01-23` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars information | {...} |
| location | string | Location of the vessel | J15 |
| grid | string | Grid of the vessel | "" |
| purpose | string | The purpose field is a comma-separated value (CSV) field, where each value is a Yes (Y) or No (N) indicator in the following sequence: #1 – Loading/Unloading Cargo, #2 – Loading/Unloading Passengers, #3 – Taking Bunker, #4 – Taking Ship Supplies, #5 – Changing Crew, #6 – Shipyard Repair, #7 – Offshore Support, #8 – Not Used, #9 – Other Afloat Activities. | Y,N,N,N,N,N,N,N,N, |
| agent | string | Agent of the vessel | INFINITI SHIPPING PTE LTD |
| reportedArrivalTime | string | The reported arrival time | 2024-01-23 15:25:00 |
| crew | string | Number of crew members | 13 |
| pax | string | Number of passengers | 0 |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | RADJA SAMUDERA ABADI |
| callSign | string | CallSign of the vessel | PKJQ |
| imoNumber | string | IMO number of the vessel | 9762156 |
| flag | string | Country flag of the vessel | ID |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "vesselParticulars": {
            "vesselName": "RADJA SAMUDERA ABADI",
            "callSign": "PKJQ",
            "imoNumber": "9762156",
            "flag": "ID"
        },
        "location": "J15",
        "grid": "",
        "purpose": "Y,N,N,N,N,N,N,N,N,",
        "agent": "INFINITI SHIPPING PTE LTD",
        "reportedArrivalTime": "2024-01-23 15:25:00",
        "crew": "13",
        "pax": "0"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/arrivaldeclaration/bydate?date=2024-01-23' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the date if needed.
- The API supports **hourly refreshed** data from the Maritime Data Hub.

---

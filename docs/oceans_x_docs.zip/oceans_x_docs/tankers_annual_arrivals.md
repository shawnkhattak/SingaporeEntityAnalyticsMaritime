---
# Tankers Annual Arrivals

**UUID:** 101271b8-ff94-491a-80e1-8514451160b6  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/101271b8-ff94-491a-80e1-8514451160b6  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/101271b8-ff94-491a-80e1-8514451160b6/documents/129c92ab-54fd-4df4-8e51-72d3e8ef0a48  
**Scraped:** 2026-04-26T05:18:53+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Tankers Annual Arrivals (ZIP) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/staticdataset/tankerAnnualArrivals`  
**Update Frequency:** Annually

---

## 🔍 **Overview**

Provides the corresponding tankers annual arrivals data in zip format.

---

## 📥 **Request**

### `GET /v1/staticdataset/tankerAnnualArrivals`

No query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="tanker-arrivals-75-gt-annual.zip"` |

#### Response Body:

Binary content of the ZIP file (`tanker-arrivals-75-gt-annual.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/staticdataset/tankerAnnualArrivals' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'tanker-arrivals-75-gt-annual.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

---
# Country Codes Data In Zipped Json Format

**UUID:** 5dc2dade-7796-4074-a126-631dcb10e114  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/5dc2dade-7796-4074-a126-631dcb10e114  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/5dc2dade-7796-4074-a126-631dcb10e114/documents/486c86da-40aa-478f-8570-52b705957c61  
**Scraped:** 2026-04-26T04:12:30+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Country Codes Data (Zipped JSON) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/mdhvessel/reference/countries/filetype/jsonzip`  
**Update Frequency:** Daily  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding country codes lookup data directly as a zipped JSON file.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /v1/mdhvessel/reference/countries/filetype/jsonzip`

No query parameters required.

---

## 🧾 **Response Details**

| Header | Type | Description | Example |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | application/zip |
| Content-Disposition | string | File attachment information | attachment; filename="COUNTRIES\_REF\_JSON.zip" |

## 📤 **Response**

### ✅ 200 OK

The response returns the country codes data directly as a zipped JSON file for download.

**Response Type:** Binary file (application/zip)  
**File Name:** COUNTRIES\_REF\_JSON.zip  
**Content:** JSON file

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/mdhvessel/reference/countries/filetype/jsonzip' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- The response returns the zipped JSON file directly in the response body for immediate download.
- No request body or query parameters required.
- The ZIP file contains JSON data

---

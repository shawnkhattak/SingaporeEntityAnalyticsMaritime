---
# Vessel Arrivals for Past ‘N’ Hours

**UUID:** 40a78f10-1397-4fcd-9e12-d351d2aa6152  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/40a78f10-1397-4fcd-9e12-d351d2aa6152  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/40a78f10-1397-4fcd-9e12-d351d2aa6152/documents/13cff88b-a1d4-441d-8b4b-27c8effc0a6b  
**Scraped:** 2026-04-26T05:20:14+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Arrivals for Past ‘N’ Hours API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/arrivals/date/{date}/hours/{hours}`  
**Update Frequency:** 1 hour  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessels arrival information for the given date and time in yyyy-MM-dd HH:mm:ss format. The data is updated every hour

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /date/{date}/hours/{hours}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | Yes | Should be in date and time (yyyy-MM-dd HH:mm:ss) format | `2025-08-30 20:20:30` |
| hours | string | Yes | Number of past hours to include. Should be in numbers. | `6` |

### 🔧 Query Parameters

*None*

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars object | {...} |
| arrivedTime | string | Arrival time (YYYY-MM-DD HH:MM:SS) | 2025-08-30 14:25:00 |
| locationFrom | string | Location from | SEAE |
| locationTo | string | Location to | PEBGC |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | TING JIANG KOU |
| callSign | string | Vessel call sign | V7A6256 |
| imoNumber | string | IMO number of the vessel | 9991783 |
| flag | string | Vessel flag | MH |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "vesselParticulars": {
            "vesselName": "TING JIANG KOU",
            "callSign": "V7A6256",
            "imoNumber": "9991783",
            "flag": "MH"
        },
        "arrivedTime": "2025-08-30 14:25:00",
        "locationFrom": "SEAE",
        "locationTo": "PEBGC"
    },
    {
        "vesselParticulars": {
            "vesselName": "CHRISTINA J",
            "callSign": "V7UE7",
            "imoNumber": "9492232",
            "flag": "MH"
        },
        "arrivedTime": "2025-08-30 14:30:00",
        "locationFrom": "SEAE",
        "locationTo": "PEBGC"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/arrivals/date/2025-08-30%2020:20:30/hours/6' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the datetime if it includes spaces.
- The API returns arrival data for the past N hours from the specified datetime.
- Ensure the `apikey` has sufficient access rights to call this endpoint.

---

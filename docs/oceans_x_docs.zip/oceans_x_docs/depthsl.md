---
# DepthsL

**UUID:** 7b22c384-1bcc-4bd1-897c-0c52cc4c18f5  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/7b22c384-1bcc-4bd1-897c-0c52cc4c18f5  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/7b22c384-1bcc-4bd1-897c-0c52cc4c18f5/documents/9ac632be-596a-4670-962a-0aee2ce248f6  
**Scraped:** 2026-04-26T05:16:03+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Depths (Line) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/depthsl-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Line features to represent depth area of a water, illustrating the shape and location of this geographic object.

These line features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S57).

This dataset is not to be used for navigation.

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/depthsl-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_depthsl.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_depthsl.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/depthsl-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_depthsl.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

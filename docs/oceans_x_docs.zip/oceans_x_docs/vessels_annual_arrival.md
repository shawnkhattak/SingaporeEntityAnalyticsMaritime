---
# Vessels Annual Arrival

**UUID:** b7837d69-eb6a-4c66-8ddb-37186e9cdf68  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/b7837d69-eb6a-4c66-8ddb-37186e9cdf68  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/b7837d69-eb6a-4c66-8ddb-37186e9cdf68/documents/f8d187ed-760d-480c-b484-fcfeb7f47ad7  
**Scraped:** 2026-04-26T05:22:46+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessels Annual Arrival (ZIP) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/staticdataset/vesselAnnualArrivals`  
**Update Frequency:** Annually

---

## 🔍 **Overview**

Provides the corresponding vessels annual arrival data in zip format.

---

## 📥 **Request**

### `GET /v1/staticdataset/vesselAnnualArrivals`

No query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="vessel-arrivals-75-gt-annual.zip"` |

#### Response Body:

Binary content of the ZIP file (`vessel-arrivals-75-gt-annual.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/staticdataset/vesselAnnualArrivals' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'vessel-arrivals-75-gt-annual.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

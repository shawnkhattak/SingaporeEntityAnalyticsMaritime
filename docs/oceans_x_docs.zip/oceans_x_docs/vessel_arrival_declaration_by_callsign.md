---
# Vessel Arrival Declaration by CallSign

**UUID:** 38f1cb38-77bb-4e08-bba8-77e368753343  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/38f1cb38-77bb-4e08-bba8-77e368753343  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/38f1cb38-77bb-4e08-bba8-77e368753343/documents/51a1225c-0233-4aba-9a92-56814178607b  
**Scraped:** 2026-04-26T05:19:36+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Arrival Declaration by Call Sign API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/arrivaldeclaration/callsign/{callsign}`  
**Update Frequency:** Hourly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessel arrival declaration information for the given vessel callsign. The data is updated every hour.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /callsign/{callsign}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| callsign | string | Yes | CallSign of the vessel | `PKJQ` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars information | {...} |
| location | string | Location of the vessel | J15 |
| grid | string | Grid of the vessel | "" |
| purpose | string | The purpose field is a comma-separated value (CSV) field, where each value is a Yes (Y) or No (N) indicator in the following sequence: #1 – Loading/Unloading Cargo, #2 – Loading/Unloading Passengers, #3 – Taking Bunker, #4 – Taking Ship Supplies, #5 – Changing Crew, #6 – Shipyard Repair, #7 – Offshore Support, #8 – Not Used, #9 – Other Afloat Activities. | Y,N,N,N,N,N,N,N,N, |
| agent | string | Agent of the vessel | INFINITI SHIPPING PTE LTD |
| reportedArrivalTime | string | The reported arrival time | 2024-01-23 15:25:00 |
| crew | string | Number of crew members | 13 |
| pax | string | Number of passengers | 0 |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | RADJA SAMUDERA ABADI |
| callSign | string | CallSign of the vessel | PKJQ |
| imoNumber | string | IMO number of the vessel | 9762156 |
| flag | string | Country flag of the vessel | ID |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "vesselParticulars": {
            "vesselName": "RADJA SAMUDERA ABADI",
            "callSign": "PKJQ",
            "imoNumber": "9762156",
            "flag": "ID"
        },
        "location": "J15",
        "grid": "",
        "purpose": "Y,N,N,N,N,N,N,N,N,",
        "agent": "INFINITI SHIPPING PTE LTD",
        "reportedArrivalTime": "2024-01-23 15:25:00",
        "crew": "13",
        "pax": "0"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/arrivaldeclaration/callsign/PKJQ' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the call sign if it includes spaces.
- The API supports **hourly refreshed** data from the Maritime Data Hub.

---

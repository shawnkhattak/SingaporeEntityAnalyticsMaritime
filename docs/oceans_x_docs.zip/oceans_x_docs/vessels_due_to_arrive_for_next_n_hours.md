---
# Vessels Due to Arrive for Next ‘N’ Hours

**UUID:** a1aa3ea6-08e7-4763-858d-b9d9d968507d  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/a1aa3ea6-08e7-4763-858d-b9d9d968507d  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/a1aa3ea6-08e7-4763-858d-b9d9d968507d/documents/a85daf59-dc70-48f8-9385-3f7fed66f8a3  
**Scraped:** 2026-04-26T05:22:58+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessels Due to Arrive for Next ‘N’ Hours API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/duetoarrive/date/{date}/hours/{hours}`  
**Update Frequency:** 1 hour  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessels that are due to arrive information for the given date and time in yyyy-MM-dd HH:mm:ss format. The data is updated every hour

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /date/{date}/hours/{hours}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | Yes | Date and time in yyyy-MM-dd HH:mm:ss format | `2025-08-30 00:20:31` |
| hours | string | Yes | Number of hours to look ahead. Should be in numbers. | `10` |

### 🔧 Query Parameters

*None*

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars object | {...} |
| duetoArriveTime | string | Due to arrive time (YYYY-MM-DD HH:MM:SS) | 2025-08-30 05:30:00 |
| locationFrom | string | Location from | SEA |
| locationTo | string | Location to | PWBGB |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | MSC DIEGO |
| callSign | string | Vessel call sign | 3FZP8 |
| imoNumber | string | IMO number of the vessel | 9202649 |
| flag | string | Vessel flag | PA |

---

## 📤 **Response**

### ✅ 200 OK

```
[
  {
    "vesselParticulars": {
      "vesselName": "MSC DIEGO",
      "callSign": "3FZP8",
      "imoNumber": "9202649",
      "flag": "PA"
    },
    "duetoArriveTime": "2025-08-30 05:30:00",
    "locationFrom": "SEA",
    "locationTo": "PWBGB"
  }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/duetoarrive/date/2025-08-30%2000:20:31/hours/10' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the date and time if needed.
- The API returns vessels due to arrive for the next N hours from the specified date and time.
- Ensure the `apikey` has sufficient access rights to call this endpoint.

---

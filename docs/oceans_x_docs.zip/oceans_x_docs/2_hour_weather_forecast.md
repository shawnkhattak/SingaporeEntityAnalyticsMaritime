---
# 2-Hour Weather Forecast

**UUID:** c4034974-483f-4c42-b80b-6e82bd2cc7bf  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/c4034974-483f-4c42-b80b-6e82bd2cc7bf  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/c4034974-483f-4c42-b80b-6e82bd2cc7bf/documents/0d075e28-898b-4670-aca9-79e1c1883243  
**Scraped:** 2026-04-26T04:11:01+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Weather - 2-Hour Forecast API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{DOMAIN}/api/weather/forecast/1.0.0/2hour-forecasts`
**Update Frequency:** 30 minutes  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Weather forecast for next 2 hours. Data is retrieved from NEA’s open data API.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /forecast/2hour`

### 🔧 Path Parameters

*None*

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | No | SGT date for which to retrieve data (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS) | `2025-07-24` or `2025-07-24T11:30:00` |
| paginationToken | string | No | Pagination token for retrieving subsequent data pages (only exists when there is a next page available for requests with date filters) | `abc123` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| code | integer | Response status code (always 0 for success) | 0 |
| data | object | Weather forecast data object | See below (Data Object) |
| errorMsg | string | Error message (empty string for success) | "" |

**Data Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| area\_metadata | array | List of forecast areas and their locations | See below (Area Metadata Object) |
| items | array | List of forecast items | See below (Item Object) |
| paginationToken | string | Token to retrieve next page if exists | b2Zmc2V0PTEwMA== |

**Area Metadata Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| name | string | Name of the area | Ang Mo Kio |
| label\_location | object | Provides longitude and latitude for placing readings on a map | See below (Label Location Object) |

**Label Location Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| latitude | number | Latitude of area | 1.375 |
| longitude | number | Longitude of area | 103.839 |

**Item Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| update\_timestamp | string | Time of acquisition of data from NEA | 2025-07-24T11:35:43+08:00 |
| timestamp | string | Time forecast was issued by NEA | 2025-07-24T11:30:00+08:00 |
| valid\_period | object | Period of time the forecast is valid for | See below (Valid Period Object) |
| forecasts | array | Forecasts for various areas in Singapore | See below (Forecast Object) |

**Valid Period Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| start | string | Start time | 2025-07-24T11:30:00+08:00 |
| end | string | End time | 2025-07-24T13:30:00+08:00 |
| text | string | Human-readable period | 11.30 am to 1.30 pm |

**Forecast Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| area | string | Area name | Ang Mo Kio |
| forecast | string | Forecast description | Partly Cloudy (Day) |

---

## 📤 **Response**

### ✅ HTTP Status Code: 200

```
{
  "code": 0,
  "data": {
    "area_metadata": [
      {
        "name": "Ang Mo Kio",
        "label_location": {
          "latitude": 1.375,
          "longitude": 103.839
        }
      },
      {
        "name": "Marina Parade",
        "label_location": {
          "latitude": 1.297,
          "longitude": 103.891
        }
      },
      {
        "name": "Sentosa",
        "label_location": {
          "latitude": 1.243,
          "longitude": 103.832
        }
      }
    ],
    "items": [
      {
        "update_timestamp": "2025-07-24T11:35:43+08:00",
        "timestamp": "2025-07-24T11:30:00+08:00",
        "valid_period": {
          "start": "2025-07-24T11:30:00+08:00",
          "end": "2025-07-24T13:30:00+08:00",
          "text": "11.30 am to 1.30 pm"
        },
        "forecasts": [
          {
            "area": "Ang Mo Kio",
            "forecast": "Partly Cloudy (Day)"
          },
          {
            "area": "Marina Parade",
            "forecast": "Partly Cloudy (Day)"
          },
          {
            "area": "Sentosa",
            "forecast": "Partly Cloudy (Day)"
          }
        ]
      }
    ],
    "paginationToken": "b2Zmc2V0PTEwMA=="
  },
  "errorMsg": ""
}
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
  "error": {
    "code": "400",
    "message": "Invalid or missing request parameters",
    "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
  }
}
```

### ❌ HTTP Status Code: 4xx/5xx from NEA:

```
{
  "code": 4,
  "name": "ERROR_PARAMS",
  "data": null,
  "errorMsg": "Invalid date format. Date format must be YYYY-MM-DD (2024-06-01) or YYYY-MM-DDTHH:mm:ss (2024-06-01T08:30:00)."
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/weather/forecast/1.0.0/2hour-forecasts?date=2025-07-24' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Updated half-hourly from NEA
- Forecasts are given for multiple areas in Singapore
- Filter for specific date or date-time by providing date in query parameter:
  - Use `YYYY-MM-DD` format to retrieve all of the readings for that day
  - Use `YYYY-MM-DDTHH:mm:ss` to retrieve the latest readings at that moment in time
  - Example: `?date=2024-07-16` or `?date=2024-07-16T23:59:00`
- If date is not provided in query parameter, API will return the latest reading
- Possible values for `forecast` include:
  - Fair
  - Fair (Day)
  - Fair (Night)
  - Fair and Warm
  - Partly Cloudy
  - Partly Cloudy (Day)
  - Partly Cloudy (Night)
  - Cloudy
  - Hazy
  - Slightly Hazy
  - Windy
  - Mist
  - Fog
  - Light Rain
  - Moderate Rain
  - Heavy Rain
  - Passing Showers
  - Light Showers
  - Showers
  - Heavy Showers
  - Thundery Showers
  - Heavy Thundery Showers
  - Heavy Thundery Showers with Gusty Winds
- Area metadata:
  - The `area_metadata` field in the response provides longitude/latitude information for the areas. You can use that to place the forecasts on a map.

---

---
# Vessel Departure Declaration by Date

**UUID:** 6e7bfce1-f0a2-4045-be67-85a54660bc26  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/6e7bfce1-f0a2-4045-be67-85a54660bc26  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/6e7bfce1-f0a2-4045-be67-85a54660bc26/documents/d8c892c3-cd3e-44db-8c0f-7b2e08d33cce  
**Scraped:** 2026-04-26T05:20:28+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 Vessel Departure Declaration by Date API

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/departuredeclaration/bydate?date={date}`  
**Update Frequency:** Hourly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 Overview

Provides all vessel departure declarations for a specific date. Data is updated hourly.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /bydate?date={date}`

### 🔧 Query Parameters

| Name | Type | Required | Description | Example |
| --- | --- | --- | --- | --- |
| date | string | Yes | Date in yyyy-MM-dd format | `2025-07-26` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars information | {...} |
| agent | string | Agent of the vessel | MAJESTIC FAST FERRY PTE LTD |
| nextPort | string | Next port | BATAM CENTRE (BATAM) |
| reportedArrivalTime | string | Reported arrival time | 2025-07-26 08:15:00 |
| reportedDepartureTime | string | Reported departure time | 2025-07-26 09:49:24 |
| crew | string | Crew count | 10 |
| pax | string | Passenger count | 249 |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | STELLAR OF MAJESTIC |
| callSign | string | CallSign of the vessel | 9VCP7 |
| imoNumber | string | IMO number of the vessel | 1103512 |
| flag | string | Country flag of the vessel | SG |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "vesselParticulars": {
            "vesselName": "STELLAR OF MAJESTIC",
            "callSign": "9VCP7",
            "imoNumber": "1103512",
            "flag": "SG"
        },
        "agent": "MAJESTIC FAST FERRY PTE LTD",
        "nextPort": "BATAM CENTRE (BATAM)",
        "reportedArrivalTime": "2025-07-26 08:15:00",
        "reportedDepartureTime": "2025-07-26 09:49:24",
        "crew": "10",
        "pax": "249"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/departuredeclaration/bydate?date=2025-07-26' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Returns all departure declarations for the given date.
- Make sure to **URL-encode** the date if it includes special characters.

---

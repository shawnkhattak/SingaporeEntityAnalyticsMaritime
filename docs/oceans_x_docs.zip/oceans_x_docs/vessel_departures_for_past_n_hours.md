---
# Vessel Departures for Past ‘N’ Hours

**UUID:** f91dafc4-19bc-498a-bca1-989feab0b46a  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/f91dafc4-19bc-498a-bca1-989feab0b46a  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/f91dafc4-19bc-498a-bca1-989feab0b46a/documents/cf47fbc7-e415-4104-8fd1-17897f04da7b  
**Scraped:** 2026-04-26T05:21:11+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Departures for Past 'N' Hours API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/departure/date/{date}/hours/{hours}`  
**Update Frequency:** 1 hour  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessels departures information for the given date and time in yyyy-MM-dd HH:mm:ss format. The data is updated every hour.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /date/{date}/hours/{hours}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| date | string | Yes | Should be in date and time (yyyy-MM-dd HH:mm:ss) format | `2025-08-30 18:58:46` |
| hours | string | Yes | Number of past hours to include. Should be in numbers. | `3` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | GOLDEN STAR 1 |
| callSign | string | Vessel call sign | 5IM444 |
| imoNumber | string | IMO number of the vessel | 8952857 |
| flag | string | Country flag of the vessel | TZ |
| departedTime | string | Vessel departed time | 2025-08-30 16:30:00 |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "vesselParticulars": {
            "vesselName": "GOLDEN STAR 1",
            "callSign": "5IM444",
            "imoNumber": "8952857",
            "flag": "TZ"
        },
        "departedTime": "2025-08-30 16:30:00"
    },
    {
        "vesselParticulars": {
            "vesselName": "ROTTERDAM PEARL V",
            "callSign": "D5ZO6",
            "imoNumber": "9557135",
            "flag": "LR"
        },
        "departedTime": "2025-08-30 18:55:00"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/departure/date/2025-08-30%2018:58:46/hours/3' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the datetime if it includes spaces or special characters.
- Ensure the `apikey` has sufficient access rights to call this endpoint.

---

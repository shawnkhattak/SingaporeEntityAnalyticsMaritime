---
# Cargo Annual Throughput

**UUID:** 135eea5c-62a5-459e-88d0-58af4c4386c2  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/135eea5c-62a5-459e-88d0-58af4c4386c2  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/135eea5c-62a5-459e-88d0-58af4c4386c2/documents  
**Scraped:** 2026-04-26T04:11:50+00:00

---

​

​

## API Documentation

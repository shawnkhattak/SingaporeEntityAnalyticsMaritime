---
# Bunkers Monthly Sales

**UUID:** a0fb5847-7dc8-483e-9ec6-3be7c465aa1c  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/a0fb5847-7dc8-483e-9ec6-3be7c465aa1c  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/a0fb5847-7dc8-483e-9ec6-3be7c465aa1c/documents  
**Scraped:** 2026-04-26T04:11:45+00:00

---

​

​

## API Documentation

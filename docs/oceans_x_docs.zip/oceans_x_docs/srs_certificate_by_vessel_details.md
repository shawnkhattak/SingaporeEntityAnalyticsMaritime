---
# SRS Certificate by Vessel Details

**UUID:** 47c673ee-6ffd-48f3-a7b3-b16571678d34  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/47c673ee-6ffd-48f3-a7b3-b16571678d34  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/47c673ee-6ffd-48f3-a7b3-b16571678d34/documents/a26a97d0-7a4b-4712-a5f8-4d8bc71cc288  
**Scraped:** 2026-04-26T05:18:47+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **SRS Certificate of Registry by Vessel Details API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/srscor/vesseldetails`  
**Update Frequency:** Hourly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding Singapore registered ships certificate information for the given vessel details. The data is updated every hour.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /vesseldetails`

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample | Regex Pattern |
| --- | --- | --- | --- | --- | --- |
| officialnumber | string | Yes | Official number of the vessel | 401405 | ^[a-zA-Z0-9]+$ |
| vesselname | string | Yes | Name of the vessel | OCEAN DROVER | ^[0-9a-zA-Z-\_.' ]+$ |
| registryportnumber | string | Yes | Registry port number | 01410E18 | ^[a-zA-Z0-9]+$ |
| imonumber | string | Either imonumber or callsign is mandatory | IMO number of the vessel | 9232852 | ^[a-zA-Z0-9]+$ |
| callsign | string | Either imonumber or callsign is mandatory | Vessel call sign | 9V9362 | ^[a-zA-Z0-9]+$ |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| shipName | string | Name of the ship | OCEAN DROVER |
| imoNumber | string | IMO number of the vessel | 9232852 |
| registrationStatus | string | Registration status | O |
| registrationDate | string | Registration date | 2018-10-10 00:00:00 |
| validityDate | string | Validity date | null |
| dateOfClosure | string | Date of closure | 2024-10-18 00:00:00 |
| certificateNumber | string | Certificate Number | COR-0001-19 |
| issueDate | string | Issue date | 2019-03-01 |

---

## 📤 **Response**

### ✅ 200 OK

```
[
    {
        "shipName": "OCEAN DROVER",
        "imoNumber": "9232852",
        "registrationStatus": "O",
        "registrationDate": "2018-10-10 00:00:00",
        "validityDate": null,
        "dateOfClosure": "2024-10-18 00:00:00",
        "certificateNumber": "COR-0001-19",
        "issueDate": "2019-03-01"
    },
    {
        "shipName": "OCEAN DROVER",
        "imoNumber": "9232852",
        "registrationStatus": "O",
        "registrationDate": "2018-10-10 00:00:00",
        "validityDate": "2019-10-10 00:00:00",
        "dateOfClosure": "2024-10-18 00:00:00",
        "certificateNumber": "COR-0995-18",
        "issueDate": "2018-10-02"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/srscor/vesseldetails?officialnumber=401405&vesselname=OCEAN%20DROVER&registryportnumber=01410E18&imonumber=9232852&callsign=9V9362' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Either imonumber or callsign is mandatory for the request details.

---

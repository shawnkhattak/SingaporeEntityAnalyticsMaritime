---
# Vessel Positions by IMO Number

**UUID:** ed7d47cb-22d6-4d9d-bd16-f2f47503a81f  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/ed7d47cb-22d6-4d9d-bd16-f2f47503a81f  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/ed7d47cb-22d6-4d9d-bd16-f2f47503a81f/documents  
**Scraped:** 2026-04-26T05:22:07+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

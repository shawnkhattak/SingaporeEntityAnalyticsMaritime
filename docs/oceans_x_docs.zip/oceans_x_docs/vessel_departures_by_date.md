---
# Vessel Departures by Date

**UUID:** 9e473ddd-1f2c-4807-8f3a-3756a0bed59f  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/9e473ddd-1f2c-4807-8f3a-3756a0bed59f  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/9e473ddd-1f2c-4807-8f3a-3756a0bed59f/documents  
**Scraped:** 2026-04-26T05:21:04+00:00

---

​

​

## API Documentation

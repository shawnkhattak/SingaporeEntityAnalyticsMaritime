---
# Vessel Annual Calls

**UUID:** 3cbcea9f-cdcd-4969-913c-1450165a840b  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/3cbcea9f-cdcd-4969-913c-1450165a840b  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/3cbcea9f-cdcd-4969-913c-1450165a840b/documents/f324d963-0a01-4c97-8eab-e802eb784bbb  
**Scraped:** 2026-04-26T05:19:29+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Annual Calls (ZIP) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/staticdataset/vesselAnnualCalls`  
**Update Frequency:** Annually

---

## 🔍 **Overview**

Provides the corresponding vessel annual calls data in zip format.

---

## 📥 **Request**

### `GET /v1/staticdataset/vesselAnnualCalls`

No query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="vessel-calls-75-gt-annual.zip"` |

#### Response Body:

Binary content of the ZIP file (`vessel-calls-75-gt-annual.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/staticdataset/vesselAnnualCalls' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'vessel-calls-75-gt-annual.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

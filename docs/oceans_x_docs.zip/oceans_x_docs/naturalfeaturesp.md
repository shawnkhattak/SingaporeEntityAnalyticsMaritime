---
# NaturalFeaturesP

**UUID:** 8f80ecd4-52de-4b41-9600-a6a413e9c8a5  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/8f80ecd4-52de-4b41-9600-a6a413e9c8a5  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/8f80ecd4-52de-4b41-9600-a6a413e9c8a5/documents/0b4082c5-4e35-440d-8f27-d25b11210037  
**Scraped:** 2026-04-26T05:16:50+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Natural Features (Point) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/naturalfeaturesp-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Point features to represent natural features such as vegetation, slopes, other water bodies, illustrating the location of this geographic object.

These point features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S-57).

This dataset is not to be used for navigation.

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/naturalfeaturesp-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_naturalfeaturesp.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_naturalfeaturesp.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/naturalfeaturesp-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_naturalfeaturesp.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

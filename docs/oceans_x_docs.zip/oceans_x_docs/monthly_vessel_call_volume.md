---
# Monthly Vessel Call Volume

**UUID:** 9645803f-8d64-43ad-a38b-0c31b1e305a1  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/9645803f-8d64-43ad-a38b-0c31b1e305a1  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/9645803f-8d64-43ad-a38b-0c31b1e305a1/documents/975432c0-c087-49ce-83a0-3968875e2bbc  
**Scraped:** 2026-04-26T04:13:22+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Distribution - Vessel Call Volume Monthly API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{DOMAIN}/api/vessel-call/1.0.0/monthly-volume`  
**Update Frequency:** Monthly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides monthly vessel call volume statistics, including breakdown by purpose type. Data is sourced from Data.gov.sg and updated monthly.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /monthly-volume`

### 🔧 Path Parameters

*None*

### 🔧 Query Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| startMonth | string | Yes | Start month in YYYY-MM format | `2012-06` |
| endMonth | string | Yes | End month in YYYY-MM format | `2021-08` |
| purposeType | string | No | Purpose type filter for vessel calls (bunkers, cargo, repairs, supplies, others) | `cargo` |
| page | integer | No | Page number (1-indexed), minimum: 1 | `1` |
| size | integer | No | Number of records per page, minimum: 1, maximum: 100 | `20` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| items | array | Array of vessel call volume records | See below (Items Array Item) |
| page | object | Pagination metadata | See below (Page Object) |
| \_links | object | Hypermedia links for navigation | See below (Links Object) |

**Items Array Item:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| month | string | Month in YYYY-MM format | "2025-05" |
| purposeType | string | Purpose type of vessel call | "bunkers" |
| numberOfVesselCalls | integer | Number of vessel calls for the purpose type | 142 |
| grossTonnage | number | Total gross tonnage for the purpose type | 2850000 |

**Page Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| number | integer | Current page number (1-indexed) | 1 |
| size | integer | Number of items per page | 3 |
| totalElements | integer | Total number of elements across all pages | 42 |
| totalPages | integer | Total number of pages | 14 |

**Links Object:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| self | object | Link to current page | `{"href": "/api/vessel-call/1.0.0/monthly-volume?startMonth=2025-05&endMonth=2025-07&purposeType=bunkers&page=2&size=3"}` |
| prev | object | Link to previous page (if exists) | `{"href": "/api/vessel-call/1.0.0/monthly-volume?startMonth=2025-05&endMonth=2025-07&purposeType=bunkers&page=1&size=3"}` |
| next | object | Link to next page (if exists) | `{"href": "/api/vessel-call/1.0.0/monthly-volume?startMonth=2025-05&endMonth=2025-07&purposeType=bunkers&page=3&size=3"}` |

---

## 📤 **Response**

### ✅ HTTP Status Code: 200

```
{
  "items": [
    {
      "month": "2025-05",
      "purposeType": "bunkers",
      "numberOfVesselCalls": 142,
      "grossTonnage": 2850000
    },
    {
      "month": "2025-06",
      "purposeType": "bunkers",
      "numberOfVesselCalls": 158,
      "grossTonnage": 3120000
    },
    {
      "month": "2025-07",
      "purposeType": "bunkers",
      "numberOfVesselCalls": 134,
      "grossTonnage": 2750000
    }
  ],
  "page": {
    "number": 1,
    "size": 3,
    "totalElements": 42,
    "totalPages": 14
  },
  "_links": {
    "self": {
      "href": "/api/vessel-call/1.0.0/monthly-volume?startMonth=2025-05&endMonth=2025-07&purposeType=bunkers&page=2&size=3"
    },
    "next": {
      "href": "/api/vessel-call/1.0.0/monthly-volume?startMonth=2025-05&endMonth=2025-07&purposeType=bunkers&page=3&size=3"
    },
    "prev": {
      "href": "/api/vessel-call/1.0.0/monthly-volume?startMonth=2025-05&endMonth=2025-07&purposeType=bunkers&page=1&size=3"
    }
  }
}
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
  "error": {
    "code": "400",
    "message": "Invalid or missing request parameters",
    "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
  }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/vessel-call/1.0.0/monthly-volume?startMonth=2012-06&endMonth=2021-08&page=1&size=20' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Data is updated monthly.
- Results are paginated. Use `page` and `size` parameters to control pagination.
- If `purposeType` is not provided, all purpose types will be included in the response.

---

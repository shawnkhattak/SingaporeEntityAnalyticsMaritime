---
# Vessel Particulars by Name

**UUID:** fd9f3ed8-0c62-431c-b2f8-d07383a3b824  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/fd9f3ed8-0c62-431c-b2f8-d07383a3b824  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/fd9f3ed8-0c62-431c-b2f8-d07383a3b824/documents/b409f604-7971-48da-b78d-b1f3da354b84  
**Scraped:** 2026-04-26T05:21:55+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Particulars by Vessel Name API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{DOMAIN}/api/v1/vessel/particulars/vesselname/{vesselname}`  
**Update Frequency:** 6 Hours  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides the corresponding vessel particulars information for the given vessel name. The data is updated every 6 hours

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /vesselname/{vesselname}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Sample |
| --- | --- | --- | --- | --- |
| vesselname | string | Yes | Name of the vessel (1-35 chars, regex: `/^[0-9a-zA-Z-_.' ]+$/`) | `BINTANG SAMUDRA` |

---

## 🧾 **Response Details**

### Singapore-flagged vessel (`flag = "SG"`)

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | I MOLA |
| callSign | string | Vessel call sign | 9V5704 |
| imoNumber | string | IMO number of the vessel | 9204025 |
| flag | string | Country flag of the vessel | SG |
| vesselLength | number | Length of the vessel | 31 |
| vesselBreadth | number | Breadth of the vessel | 7 |
| vesselDepth | number | Depth of the vessel | 2 |
| vesselType | string | Type of vessel | FB |
| grossTonnage | number | Gross tonnage of the vessel | 240 |
| netTonnage | number | Net tonnage of the vessel | 72 |
| deadweight | number | Dead weight of the vessel | 0 |
| mmsiNumber | string | MMSI number of the vessel | 564759000 |
| yearBuilt | string | Year built | 1995 |
| ismManager | string | ISM Manager | SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD |
| shipManager | string | Ship Manager | SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD |
| registeredOwnership | string | Registered Ownership | SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD |
| classificationSociety | string | Classification Society | MPA |

### Non-Singapore-flagged vessel (`flag != "SG"`)

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | BINTANG SAMUDRA |
| callSign | string | Vessel call sign | YGVE |
| imoNumber | string | IMO number of the vessel | 0 |
| flag | string | Country flag of the vessel | ID |
| vesselLength | number | Length of the vessel | 61 |
| vesselBreadth | number | Breadth of the vessel | 0 |
| vesselDepth | number | Depth of the vessel | 0 |
| vesselType | string | Type of vessel | LC |
| grossTonnage | number | Gross tonnage of the vessel | 567 |
| netTonnage | number | Net tonnage of the vessel | 171 |
| deadweight | number | Dead weight of the vessel | 0 |
| mmsiNumber | string | MMSI number of the vessel | 0 |
| yearBuilt | string | Year built | 2000 |

---

## 📤 **Response**

### ✅ HTTP Status Code: 200

#### Case 1: Singapore-flagged vessel (`flag = "SG"`)

```
[
    {
        "vesselName": "I MOLA",
        "callSign": "9V5704",
        "imoNumber": "9204025",
        "flag": "SG",
        "vesselLength": 31,
        "vesselBreadth": 7,
        "vesselDepth": 2,
        "vesselType": "FB",
        "grossTonnage": 240,
        "netTonnage": 72,
        "deadweight": 0,
        "mmsiNumber": "564759000",
        "yearBuilt": "1995",
        "ismManager": "SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD",
        "shipManager": "SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD",
        "registeredOwnership": "SINGAPORE ISLAND CRUISE & FERRY SERVICES PTE LTD",
        "classificationSociety": "MPA"
    }
]
```

#### Case 2: Non-Singapore-flagged vessel (`flag != "SG"`)

```
[
    {
        "vesselName": "BINTANG SAMUDRA",
        "callSign": "YGVE",
        "imoNumber": "0",
        "flag": "ID",
        "vesselLength": 61,
        "vesselBreadth": 0,
        "vesselDepth": 0,
        "vesselType": "LC",
        "grossTonnage": 567,
        "netTonnage": 171,
        "deadweight": 0,
        "mmsiNumber": "0",
        "yearBuilt": "2000"
    }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/particulars/vesselname/BINTANG%20SAMUDRA' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Make sure to **URL-encode** the vessel name if it includes spaces.
- Ensure the `apikey` has sufficient access rights to call this endpoint.

---

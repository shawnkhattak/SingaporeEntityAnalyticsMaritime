---
# Vessel Arrival Declaration for Past ‘N’ Hours

**UUID:** ca0ce2ae-e739-40a5-ae9e-fd7deed7a8dc  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/ca0ce2ae-e739-40a5-ae9e-fd7deed7a8dc  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/ca0ce2ae-e739-40a5-ae9e-fd7deed7a8dc/documents  
**Scraped:** 2026-04-26T05:20:01+00:00

---

​

​

## API Documentation

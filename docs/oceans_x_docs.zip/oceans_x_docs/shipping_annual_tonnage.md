---
# Shipping Annual Tonnage

**UUID:** 012c710f-91e7-4e81-aad7-1059658f88a6  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/012c710f-91e7-4e81-aad7-1059658f88a6  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/012c710f-91e7-4e81-aad7-1059658f88a6/documents/cf99f2e3-cb81-4fbc-be07-21a317843c41  
**Scraped:** 2026-04-26T05:18:04+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Shipping Annual Tonnage (ZIP) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/staticdataset/vesselShippingAnnualTonnage`  
**Update Frequency:** Annually

---

## 🔍 **Overview**

Provides the corresponding shipping annual tonnage data in zip format.

---

## 📥 **Request**

### `GET /v1/staticdataset/vesselShippingAnnualTonnage`

No query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="registered-vessels-and-shipping-tonnage-annual.zip"` |

#### Response Body:

Binary content of the ZIP file (`registered-vessels-and-shipping-tonnage-annual.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/staticdataset/vesselShippingAnnualTonnage' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'registered-vessels-and-shipping-tonnage-annual.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

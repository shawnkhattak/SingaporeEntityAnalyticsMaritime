---
# Vessel Departure Declaration by CallSign

**UUID:** ac5efca9-e894-43b7-a3f5-2836a06555c3  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/ac5efca9-e894-43b7-a3f5-2836a06555c3  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/ac5efca9-e894-43b7-a3f5-2836a06555c3/documents/4b050fdf-790f-4062-9e53-27d6f9a61030  
**Scraped:** 2026-04-26T05:20:21+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 Vessel Departure Declaration by CallSign API

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/departuredeclaration/callsign/{callsign}`  
**Update Frequency:** Hourly  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 Overview

Provides the vessel departure declaration information for the given vessel call sign. Data is updated hourly.

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /callsign/{callsign}`

### 🔧 Path Parameters

| Name | Type | Required | Description | Example |
| --- | --- | --- | --- | --- |
| callsign | string | Yes | Call sign of vessel | `9VCP7` |

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars information | {...} |
| agent | string | Agent of the vessel | MAJESTIC FAST FERRY PTE LTD |
| nextPort | string | Next port | BATAM CENTRE (BATAM) |
| reportedArrivalTime | string | Reported arrival time | 2025-07-26 08:15:00 |
| reportedDepartureTime | string | Reported departure time | 2025-07-26 09:49:24 |
| crew | string | Crew count | 10 |
| pax | string | Passenger count | 249 |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | STELLAR OF MAJESTIC |
| callSign | string | CallSign of the vessel | 9VCP7 |
| imoNumber | string | IMO number of the vessel | 1103512 |
| flag | string | Country flag of the vessel | SG |

---

## 📤 **Response**

### ✅ 200 OK

```
[
  {
    "vesselParticulars": {
      "vesselName": "STELLAR OF MAJESTIC",
      "callSign": "9VCP7",
      "imoNumber": "1103512",
      "flag": "SG"
    },
    "agent": "MAJESTIC FAST FERRY PTE LTD",
    "nextPort": "BATAM CENTRE (BATAM)",
    "reportedArrivalTime": "2025-07-26 08:15:00",
    "reportedDepartureTime": "2025-07-26 09:49:24",
    "crew": "10",
    "pax": "249"
  }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/departuredeclaration/callsign/9VCP7' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- Returns all departure declarations for the given call sign.
- Make sure to **URL-encode** the call sign if it includes spaces or special characters.

---

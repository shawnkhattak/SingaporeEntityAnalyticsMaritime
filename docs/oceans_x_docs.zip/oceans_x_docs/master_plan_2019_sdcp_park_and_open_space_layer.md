---
# Master Plan 2019 SDCP Park and Open Space layer

**UUID:** 23d2602c-691c-480a-ac6f-b8a0b5209f7e  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/23d2602c-691c-480a-ac6f-b8a0b5209f7e  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/23d2602c-691c-480a-ac6f-b8a0b5209f7e/documents/756feb55-e0b4-40a2-8a76-4af35327549e  
**Scraped:** 2026-04-26T05:16:23+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Master Plan Park Open Space Layer API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/ura/master-plan-park-open-space-layer`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Provides access to the URA Master Plan Park Open Space Layer dataset. This API returns a reference URL to the data.gov.sg portal where the dataset collection can be accessed and downloaded.

---

## 📥 **Request**

### `GET /v1/gssdataset/ura/master-plan-park-open-space-layer`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response contains a JSON object with a `location` field pointing to the data.gov.sg collection page.

#### Response Body:

```
{
    "location": "https://data.gov.sg/collections/1650/view"
}
```

#### Response Fields:

| Field | Type | Description |
| --- | --- | --- |
| location | string | URL to the data.gov.sg collection page where the Master Plan Park Open Space Layer dataset can be accessed and downloaded |

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/ura/master-plan-park-open-space-layer' \
  -H 'ApiKey: YOUR_API_KEY'
```

---

## 📎 Notes

- The API returns a reference URL to data.gov.sg, not the actual dataset file.
- Users should navigate to the provided URL to access and download the dataset from data.gov.sg.
- No request body or query parameters required.

---

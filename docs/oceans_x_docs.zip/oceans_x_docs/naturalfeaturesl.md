---
# NaturalFeaturesL

**UUID:** 8387b032-1a72-4b74-a1bf-40a798e509ed  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/8387b032-1a72-4b74-a1bf-40a798e509ed  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/8387b032-1a72-4b74-a1bf-40a798e509ed/documents/f8ef9a3a-4cad-4b77-b682-ef83963cc685  
**Scraped:** 2026-04-26T05:16:43+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Natural Features (Line) API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/gssdataset/mpa/naturalfeaturesl-zip`  
**Update Frequency:** As needed

---

## 🔍 **Overview**

Line features to represent natural features such as vegetation, slopes, other water bodies, illustrating the shape and location of this geographic object.

These line features are extracted from International Hydrographic Organization (IHO) standards for the exchange of digital chart information (S-57).

This dataset is not to be used for navigation

---

## 📥 **Request**

### `GET /v1/gssdataset/mpa/naturalfeaturesl-zip`

No path or query parameters required.

---

## 📤 **Response**

### ✅ 200 OK

The response directly returns the ZIP file content with appropriate headers for file download.

#### Response Headers:

| Header | Type | Description | Example Value |
| --- | --- | --- | --- |
| Content-Type | string | MIME type of the response | `application/zip` |
| Content-Disposition | string | Instructs browser to download the file | `attachment; filename="mpa_naturalfeaturesl.zip"` |

#### Response Body:

Binary content of the ZIP file (`mpa_naturalfeaturesl.zip`).

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "404",
        "message": "The requested URI does not exist",
        "timestamp": "Tue, 09 Dec 2025 05:43:01 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/gssdataset/mpa/naturalfeaturesl-zip' \
  -H 'ApiKey: YOUR_API_KEY' \
  --output 'mpa_naturalfeaturesl.zip'
```

---

## 📎 Notes

- The ZIP file is returned directly in the response body.
- The `Content-Disposition` header ensures the file is downloaded with the correct filename.
- No request body or query parameters required.

---

---
# Vessel Positions Snapshot

**UUID:** 1b2ee1ae-1693-4e34-873f-fbdcbb335ac9  
**URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/1b2ee1ae-1693-4e34-873f-fbdcbb335ac9  
**Docs URL:** https://oceans-x.mpa.gov.sg/marketplace/apis/1b2ee1ae-1693-4e34-873f-fbdcbb335ac9/documents/25939af0-25d3-43d4-bae8-928860915fc3  
**Scraped:** 2026-04-26T05:22:21+00:00

---

​

​

#### API Documentation

Select Documents

Select Documents

Document

# 📄 **Vessel Positions Snapshot API**

**Version:** 1.0.0  
**Live Endpoint:** `https://{{DOMAIN}}/api/v1/vessel/positions/snapshot`  
**Update Frequency:** 3 minutes  
**Authentication:** `API Key` (via `apikey` header)

---

## 🔍 **Overview**

Provides a snapshot of vessel positions information. The data is updated every 3 minutes

---

## 🔐 **Authentication**

All requests must include a valid API key in the request header.

### Header:

| Key | Value |
| --- | --- |
| apikey | `{Your API Key}` |

---

## 📥 **Request**

### `GET /snapshot`

This endpoint does not require any path or query parameters.

---

## 🧾 **Response Details**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselParticulars | object | Vessel particulars object | {...} |
| latitude | number | Latitude | 0.0241476315047 |
| longitude | number | Longitude | 1.80084330648 |
| latitudeDegrees | number | Latitude in degrees | 1.38355737046 |
| longitudeDegrees | number | Longitude in degrees | 103.180721026 |
| speed | number | Speed | 5.17939 |
| course | number | Course | 127.988 |
| heading | number | Heading | 0 |
| dimA | number | Dimension A | 90 |
| dimB | number | Dimension B | 20 |
| timeStamp | string | Last Update Time | 2024-09-06 15:32:52 |

**vesselParticulars attributes:**

| Attribute | Type | Description | Example |
| --- | --- | --- | --- |
| vesselName | string | Name of the vessel | A P MOLLER TEST |
| callSign | string | CallSign of the vessel | OVYQ2 |
| imoNumber | string | IMO number of the vessel | 9214898 |
| flag | string | Country flag of the vessel | DK |
| vesselLength | number | Vessel length | 347 |
| vesselBreadth | number | Vessel breadth | 0 |
| vesselDepth | number | Vessel depth | 0 |
| vesselType | string | Type of vessel | CS |
| grossTonnage | number | Vessel gross tonnage | 91560 |
| netTonnage | number | Vessel net tonnage | 50110 |
| deadweight | number | Deadweight | 0 |
| mmsiNumber | string | MMSI number | 219882000 |
| yearBuilt | string | Built in year | 1999 |

---

## 📤 **Response**

### ✅ 200 OK

```
[
  {
    "vesselParticulars": {
      "vesselName": "A P MOLLER TEST",
      "callSign": "OVYQ2",
      "imoNumber": "9214898",
      "flag": "DK",
      "vesselLength": 347,
      "vesselBreadth": 0,
      "vesselDepth": 0,
      "vesselType": "CS",
      "grossTonnage": 91560,
      "netTonnage": 50110,
      "deadweight": 0,
      "mmsiNumber": "219882000",
      "yearBuilt": "1999"
    },
    "latitude": 0.0241476315047,
    "longitude": 1.80084330648,
    "latitudeDegrees": 1.38355737046,
    "longitudeDegrees": 103.180721026,
    "speed": 5.17939,
    "course": 127.988,
    "heading": 0,
    "dimA": 90,
    "dimB": 20,
    "timeStamp": "2024-09-06 15:32:52"
  }
]
```

### ❌ HTTP Status Code: 4xx/5xx

```
{
    "error": {
        "code": "400",
        "message": "Invalid or missing request parameters",
        "timestamp": "Wed, 15 Oct 2025 06:39:27 UTC"
    }
}
```

---

## 💡 **Sample Curl Request**

```
curl -X GET \
  'https://{{DOMAIN}}/api/v1/vessel/positions/snapshot' \
  -H 'apikey: YOUR_API_KEY'
```

---

## 📎 Notes

- All coordinates are in decimal degrees.
